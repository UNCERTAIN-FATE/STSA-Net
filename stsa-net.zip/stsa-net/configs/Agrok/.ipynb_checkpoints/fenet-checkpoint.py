_base_ = '../_base_/datasets/img_dataset.py'


model = dict(
  type="FENet",
)
