_base_ = '_base_/img_dataset.py'

model = dict(
  type="srfbn",
  scale=5
)
