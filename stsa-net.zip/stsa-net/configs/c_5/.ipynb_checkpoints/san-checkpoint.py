_base_ = '_base_/img_dataset.py'

model = dict(
  type="SAN",
  scale=5
)
