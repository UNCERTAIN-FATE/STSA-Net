"""
MambaDIST_BasicBlock: Mamba增强的双分支动态解混模块

创新点：
1. Mamba双分支：静态卷积(局部) + Mamba分支(全局)
2. 双向SSM扫描：捕获全局稀疏模式
3. 自适应门控融合：动态平衡局部和全局特征
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from einops import rearrange

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 轻量级Mamba组件 ====================

class SimplifiedSSM(nn.Module):
    """简化的状态空间模型"""
    def __init__(self, dim, d_state=8, kernel_size=7):
        super().__init__()
        self.dim = dim
        self.d_state = d_state
        
        # 输入投影
        self.in_proj = nn.Linear(dim, dim * 2)
        
        # 用大核深度卷积模拟序列扫描
        self.conv = nn.Conv1d(
            dim, dim, kernel_size, 
            padding=kernel_size//2, groups=dim
        )
        
        # 门控
        self.gate = nn.Sequential(
            nn.Linear(dim, dim),
            nn.Sigmoid()
        )
        
        # 输出投影
        self.out_proj = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        
    def forward(self, x):
        """x: (B, L, D)"""
        B, L, D = x.shape
        residual = x
        
        # 输入投影+门控
        xz = self.in_proj(x)
        x, z = xz.chunk(2, dim=-1)
        
        # 序列卷积
        x = x.transpose(1, 2)  # (B, D, L)
        x = self.conv(x)
        x = x.transpose(1, 2)  # (B, L, D)
        x = F.silu(x)
        
        # 门控输出
        x = x * F.silu(z)
        x = self.out_proj(x)
        
        return self.norm(x + residual)


class BidirectionalSSM(nn.Module):
    """双向SSM扫描"""
    def __init__(self, dim, d_state=8):
        super().__init__()
        self.ssm_fwd = SimplifiedSSM(dim, d_state)
        self.ssm_bwd = SimplifiedSSM(dim, d_state)
        self.fusion = nn.Linear(dim * 2, dim)
        self.norm = nn.LayerNorm(dim)
        
    def forward(self, x):
        y_fwd = self.ssm_fwd(x)
        y_bwd = self.ssm_bwd(torch.flip(x, dims=[1]))
        y_bwd = torch.flip(y_bwd, dims=[1])
        out = self.fusion(torch.cat([y_fwd, y_bwd], dim=-1))
        return self.norm(out)


class LightweightRSSB(nn.Module):
    """轻量级残差状态空间块"""
    def __init__(self, dim, d_state=8):
        super().__init__()
        
        # 局部卷积
        self.local_conv = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        
        # 双向SSM
        self.ssm = BidirectionalSSM(dim, d_state)
        
        # 通道注意力
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        B, C, H, W = x.shape
        identity = x
        
        # 局部增强
        x = self.local_conv(x)
        
        # SSM处理
        x_seq = rearrange(x, 'b c h w -> b (h w) c')
        x_seq = self.ssm(x_seq)
        x = rearrange(x_seq, 'b (h w) c -> b c h w', h=H, w=W)
        
        # 通道注意力
        x = x * self.ca(x)
        
        return identity + self.gamma * x


# ==================== Mamba增强动态阈值生成器 ====================

class MambaDTG(nn.Module):
    """Mamba增强的动态阈值生成器"""
    def __init__(self, channels, d_state=8):
        super().__init__()
        
        # 特征提取
        self.feat_extract = nn.Sequential(
            nn.Conv2d(channels, channels, 3, 1, 1, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.GELU()
        )
        
        # Mamba全局建模
        self.mamba = LightweightRSSB(channels, d_state)
        
        # 阈值预测
        self.threshold_pred = nn.Sequential(
            nn.Conv2d(channels, channels // 2, 1),
            nn.GELU(),
            nn.Conv2d(channels // 2, channels, 1),
            nn.Softplus()
        )
        
    def forward(self, x):
        feat = self.feat_extract(x)
        feat = self.mamba(feat)
        threshold = self.threshold_pred(feat) * 0.1
        return threshold


# ==================== 主模块 ====================

class MambaDIST_BasicBlock(nn.Module):
    """
    MambaDIST BasicBlock
    
    保留原始DIST设计：
    - 双分支结构
    - 对称约束
    - 兼容原有接口
    
    创新改进：
    - 用Mamba分支替代动态卷积分支
    - 全局感受野捕获稀疏模式
    - 自适应门控融合
    """
    def __init__(self, **kwargs):
        super(MambaDIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # ===== 分支1: 静态卷积（保持原设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 分支2: Mamba分支（替代动态卷积）=====
        self.mamba_branch = nn.Sequential(
            nn.Conv2d(1, 64, 3, 1, 1),
            nn.GELU(),
            LightweightRSSB(64, d_state=8),
        )
        
        # ===== 自适应融合门控 =====
        self.fusion_gate = nn.Sequential(
            nn.Conv2d(128, 64, 1),
            nn.GELU(),
            nn.Conv2d(64, 2, 1),
            nn.Softmax(dim=1)
        )
        
        # ===== Mamba增强的软阈值 =====
        self.mamba_dtg = MambaDTG(64, d_state=8)
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = lambda_weight
        
    def forward(self, x, PhiTPhi, PhiTb):
        # 保存用于动态分支
        x_input_flat = x
        
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 分支1: 静态卷积 =====
        x_static = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_static = F.relu(x_static)
        x_static = F.conv2d(x_static, self.conv2_forward, padding=1)
        
        # ===== 分支2: Mamba分支 =====
        x_mamba = self.mamba_branch(x_input)
        
        # ===== 自适应门控融合 =====
        concat = torch.cat([x_static, x_mamba], dim=1)
        gate = self.fusion_gate(concat)  # (B, 2, H, W)
        x_fused = gate[:, 0:1] * x_static + gate[:, 1:2] * x_mamba
        
        # ===== Mamba动态阈值 + 软阈值 =====
        threshold = self.mamba_dtg(x_fused)
        x_thresh = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # ===== 后向变换 =====
        x_back = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_back = F.relu(x_back)
        x_backward = F.conv2d(x_back, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 计算对称损失 =====
        x_sym = F.conv2d(x_fused, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]