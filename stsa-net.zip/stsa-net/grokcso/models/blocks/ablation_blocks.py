"""
消融实验Block定义

使用方法：
1. 将此文件复制到 grokcso/models/blocks/ 目录
2. 在 blocks/__init__.py 中添加导入
3. 创建配置文件并训练

消融实验设计：
| 配置 | RSSB | STSC | AST | Block名称 |
|------|------|------|-----|-----------|
| (b) +RSSB | ✅ | ❌ | ❌ | Ablation_RSSB_Only_Block |
| (c) +RSSB+STSC | ✅ | ✅ | ❌ | Ablation_RSSB_STSC_Block |
| (d) +RSSB+AST | ✅ | ❌ | ✅ | Ablation_RSSB_AST_Block |
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 公共模块 ====================

class SimpleRSSB(nn.Module):
    """RSSB模块（与CSIST_RSSB_DIST_block.py中相同）"""
    def __init__(self, dim):
        super().__init__()
        self.conv1 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.global_conv = nn.Conv2d(dim, dim, 7, 1, 3, groups=dim)
        self.channel_mix = nn.Sequential(
            nn.Conv2d(dim, dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(dim * 2, dim, 1)
        )
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        x = self.conv1(x)
        x = F.gelu(x)
        x = x + self.global_conv(x)
        x = self.channel_mix(x)
        x = self.conv2(x)
        x = x * self.ca(x)
        return identity + self.gamma * x


class SmallTargetSensitiveConv(nn.Module):
    """STSC模块（创新点1）"""
    def __init__(self, dim):
        super().__init__()
        self.conv1x1 = nn.Conv2d(dim, dim, 1, 1, 0)
        self.conv3x3 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.center_attention = nn.Sequential(
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.enhance = nn.Sequential(
            nn.Conv2d(dim, dim, 1),
            nn.GELU(),
            nn.Conv2d(dim, dim, 1)
        )
        
    def forward(self, x):
        f1 = self.conv1x1(x)
        f3 = self.conv3x3(x)
        alpha = torch.sigmoid(self.alpha)
        f_multi = alpha * f1 + (1 - alpha) * f3
        attn = self.center_attention(f_multi)
        f_weighted = f_multi * attn
        out = self.enhance(f_weighted)
        return x + out


class AdaptiveSparseThreshold(nn.Module):
    """AST模块（创新点2）"""
    def __init__(self, dim, base_threshold=0.01):
        super().__init__()
        self.base_threshold = nn.Parameter(torch.tensor(base_threshold))
        self.stat_encoder = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(dim, dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(dim // 4, 1),
            nn.Softplus()
        )
        self.spatial_mod = nn.Sequential(
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, 1, 1),
            nn.Sigmoid()
        )
        self.tau_min = 1e-4
        self.tau_max = 0.05
        
    def forward(self, x):
        B, C, H, W = x.shape
        stat_mod = self.stat_encoder(x)
        spatial_mod = self.spatial_mod(x)
        threshold = self.base_threshold * (1 + 0.1 * stat_mod.view(B, 1, 1, 1)) * (0.5 + spatial_mod)
        threshold = torch.clamp(threshold, self.tau_min, self.tau_max)
        x_thresh = torch.sign(x) * F.relu(torch.abs(x) - threshold)
        return x_thresh


# ==================== 消融配置(b): 只有RSSB ====================

class Ablation_RSSB_Only_Block(nn.Module):
    """
    消融实验(b): 只有RSSB，没有STSC和AST
    用于验证RSSB的基础贡献
    """
    def __init__(self, **kwargs):
        super(Ablation_RSSB_Only_Block, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 静态分支
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # RSSB分支
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # 固定软阈值（原始设计）
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        # 后向变换
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # RSSB分支
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # 固定软阈值（无STSC，无AST）
        x_thresh = torch.mul(torch.sign(x_combined), 
                            F.relu(torch.abs(x_combined) - self.soft_thr))
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 消融配置(c): RSSB + STSC ====================

class Ablation_RSSB_STSC_Block(nn.Module):
    """
    消融实验(c): RSSB + STSC，没有AST
    用于验证STSC的贡献
    """
    def __init__(self, **kwargs):
        super(Ablation_RSSB_STSC_Block, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 静态分支
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # RSSB分支
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # STSC模块（创新点1）
        self.stsc = SmallTargetSensitiveConv(64)
        
        # 固定软阈值（无AST）
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        # 后向变换
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # RSSB分支
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # STSC（有）
        x_stsc = self.stsc(x_combined)
        
        # 固定软阈值（无AST）
        x_thresh = torch.mul(torch.sign(x_stsc), 
                            F.relu(torch.abs(x_stsc) - self.soft_thr))
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_stsc, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 消融配置(d): RSSB + AST ====================

class Ablation_RSSB_AST_Block(nn.Module):
    """
    消融实验(d): RSSB + AST，没有STSC
    用于验证AST的贡献
    """
    def __init__(self, **kwargs):
        super(Ablation_RSSB_AST_Block, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 静态分支
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # RSSB分支
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # AST模块（创新点2）
        self.ast = AdaptiveSparseThreshold(64, base_threshold=0.01)
        
        # 后向变换
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # RSSB分支
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # 无STSC，直接AST
        x_thresh = self.ast(x_combined)
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试 ====================

if __name__ == "__main__":
    print("Testing Ablation Blocks...")
    
    batch_size = 4
    c = 3
    
    configs = [
        ("Ablation_RSSB_Only_Block", Ablation_RSSB_Only_Block),
        ("Ablation_RSSB_STSC_Block", Ablation_RSSB_STSC_Block),
        ("Ablation_RSSB_AST_Block", Ablation_RSSB_AST_Block),
    ]
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    print("\n" + "=" * 50)
    for name, BlockClass in configs:
        block = BlockClass(c=c, lambda_weight=0.7).to(device)
        output, symloss = block(x, PhiTPhi, PhiTb)
        params = sum(p.numel() for p in block.parameters())
        print(f"{name}:")
        print(f"  Output shape: {output.shape}")
        print(f"  Parameters: {params:,}")
        print()
    
    print("All tests passed!")