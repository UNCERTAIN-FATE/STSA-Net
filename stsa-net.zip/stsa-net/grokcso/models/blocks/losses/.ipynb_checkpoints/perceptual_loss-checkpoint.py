# paste into grokcso/models/losses/perceptual_loss.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

class PerceptualLoss(nn.Module):
    """VGG感知损失 - 提升重建的视觉质量"""
    def __init__(self, layers=['relu1_2', 'relu2_2', 'relu3_3'], weights=[1.0, 1.0, 1.0]):
        super().__init__()
        vgg = models.vgg16(pretrained=True).features
        self.slices = []
        self.weights = weights
        
        # 定义层的切片
        slice_points = {
            'relu1_2': 4,
            'relu2_2': 9,
            'relu3_3': 16,
            'relu4_3': 23
        }
        
        prev_idx = 0
        for layer_name in layers:
            idx = slice_points[layer_name]
            self.slices.append(vgg[prev_idx:idx])
            prev_idx = idx
        
        # 冻结VGG参数
        for slice in self.slices:
            for param in slice.parameters():
                param.requires_grad = False
        
        self.slices = nn.ModuleList(self.slices)
        
    def forward(self, pred, target):
        """
        pred: [B, C, H, W] 预测图像
        target: [B, C, H, W] 目标图像
        """
        # 如果是单通道，复制到3通道
        if pred.shape[1] == 1:
            pred = pred.repeat(1, 3, 1, 1)
            target = target.repeat(1, 3, 1, 1)
        
        # 归一化到ImageNet的均值和标准差
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(pred.device)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(pred.device)
        
        pred = (pred - mean) / std
        target = (target - mean) / std
        
        loss = 0.0
        x_pred = pred
        x_target = target
        
        for i, slice in enumerate(self.slices):
            x_pred = slice(x_pred)
            x_target = slice(x_target)
            loss += self.weights[i] * F.l1_loss(x_pred, x_target)
        
        return loss

class CombinedLoss(nn.Module):
    """组合损失：MSE + 感知损失 + 对称损失"""
    def __init__(self, mse_weight=1.0, perceptual_weight=0.1, sym_weight=0.01):
        super().__init__()
        self.mse_weight = mse_weight
        self.perceptual_weight = perceptual_weight
        self.sym_weight = sym_weight
        
        self.perceptual_loss = PerceptualLoss()
        self.mse_loss = nn.MSELoss()
        
    def forward(self, pred, target, symloss):
        """
        pred: [B, N] 预测的展平图像
        target: [B, N] 目标的展平图像
        symloss: [B, 1, H, H] 对称损失
        """
        # 重建损失（MSE）
        mse = self.mse_loss(pred, target)
        
        # 将展平的图像转换为2D用于感知损失
        B = pred.shape[0]
        H = int(pred.shape[1] ** 0.5)
        pred_img = pred.view(B, 1, H, H)
        target_img = target.view(B, 1, H, H)
        
        # 感知损失
        perceptual = self.perceptual_loss(pred_img, target_img)
        
        # 对称损失
        sym = torch.mean(torch.pow(symloss, 2))
        
        # 组合
        total_loss = (self.mse_weight * mse + 
                     self.perceptual_weight * perceptual + 
                     self.sym_weight * sym)
        
        return total_loss, {
            'mse': mse,
            'perceptual': perceptual,
            'sym': sym
        }

# ==========================================
# 修改DISTA模型以使用新损失
# paste into grokcso/models/dista.py (在训练部分)
# ==========================================

# 在DISTA类的__init__中添加：
# self.combined_loss = CombinedLoss(
#     mse_weight=1.0, 
#     perceptual_weight=0.1,  # 可调
#     sym_weight=0.01
# )

# 在training_step中替换损失计算：
# loss, loss_dict = self.combined_loss(x_output, batch_y, symloss)
# self.log_dict(loss_dict, prog_bar=True)
# return loss