# grokcso/models/blocks/learnable_phi_q.py
# -*- coding: utf-8 -*-
"""
End-to-end Learnable Phi (sensing) and Q (initial reconstruction)
Designed to integrate into DISTA-like unrolled networks.

Usage:
    - Put this file into your repo (e.g. grokcso/models/blocks/)
    - 在 dista.py 中用 LearnablePhi/ LearnableQ 替换原始 .mat 加载逻辑
    - Forward pipeline:
        x: (B,1,H,W) ground-truth image patch
        y = Phi(x)                       # (B, M)
        x0 = Q(y)                        # (B, N) initial recon vector
        pass x0 to DISTA blocks as before
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def l2norm_rows(mat, eps=1e-8):
    # mat: (..., M, N) or (M,N)
    with torch.no_grad():
        row_norm = torch.norm(mat, dim=-1, keepdim=True).clamp_min(eps)
        mat.div_(row_norm)
    return mat


class LearnablePhi(nn.Module):
    """
    Learnable sensing matrix Phi: R^{N} -> R^{M}
    Implementation: a Linear layer without bias (M x N).
    Options:
      - row_norm: keep each row normalized (unit-norm) (physically meaningful for many optics settings)
      - orth_reg_weight: optional orthogonality penalty weight (||Phi Phi^T - I||_F)
      - structured: if True, uses convolutional structured sensing (not implemented here)
    """
    def __init__(self, N, M, row_norm=True, init_scale=1.0, orth_reg_weight=1e-3):
        super().__init__()
        self.N = N
        self.M = M
        self.row_norm = row_norm
        self.orth_reg_weight = float(orth_reg_weight)

        # parameter: weight shape (M, N)
        self.weight = nn.Parameter(torch.randn(M, N) * (init_scale / math.sqrt(N)))

    def forward(self, x, add_noise_std=0.0):
        """
        x: (B, N) or (B,1,H,W) flattened externally
        returns: y (B, M)
        """
        if x.dim() == 4:
            B, C, H, W = x.shape
            assert C == 1
            x = x.view(B, -1)

        w = self.weight
        if self.row_norm:
            # normalize rows to unit norm (in forward, for differentiability use normalized copy)
            w = w / (torch.norm(w, dim=1, keepdim=True) + 1e-8)

        y = F.linear(x, w)  # (B, M)
        if add_noise_std and add_noise_std > 0.0:
            y = y + torch.randn_like(y) * float(add_noise_std)
        return y

    def orth_reg(self):
        """
        Orthogonality regularizer: ||Phi Phi^T - I||_F
        Lower is better. Only meaningful when M <= N typically.
        """
        W = self.weight  # (M,N)
        device = W.device
        if self.row_norm:
            Wn = W / (torch.norm(W, dim=1, keepdim=True) + 1e-8)
        else:
            Wn = W
        G = torch.matmul(Wn, Wn.t())  # (M,M)
        Id = torch.eye(self.M, device=device)
        return torch.norm(G - Id, p='fro')

    def extra_repr(self):
        return f"N={self.N}, M={self.M}, row_norm={self.row_norm}"


class LearnableQ(nn.Module):
    """
    Learnable initial reconstruction Q: R^{M} -> R^{N}
    Two implementations:
      - Linear: simple pseudo-inverse-like (Linear without bias)
      - Linear+smallCNN: map to image-shaped tensor then refine by small conv
    Arguments:
      - mode: 'linear' or 'linear-cnn'
    """
    def __init__(self, N, M, H=None, W=None, mode='linear', hidden=64):
        super().__init__()
        self.N = N
        self.M = M
        self.mode = mode
        self.H = H
        self.W = W
        assert mode in ['linear', 'linear-cnn']
        self.linear = nn.Linear(M, N, bias=False)
        if mode == 'linear-cnn':
            assert H is not None and W is not None, "Provide H,W when using linear-cnn"
            # small 2-layer conv refinement
            # linear -> (B,1,H,W) -> conv features -> back to vector
            self.refine = nn.Sequential(
                nn.Conv2d(1, hidden, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(hidden, 1, 3, padding=1)
            )

    def forward(self, y):
        """
        y: (B,M)
        returns: x0 (B, N) & optionally x0_img (B,1,H,W) if H,W provided
        """
        B = y.shape[0]
        x0 = self.linear(y)  # (B,N)
        if self.mode == 'linear-cnn':
            x0_img = x0.view(B, 1, self.H, self.W)
            x0_img = self.refine(x0_img)
            x0 = x0_img.view(B, -1)
            return x0, x0_img
        else:
            return x0


###############################################################################
# Utilities: loss functions and an example training loop integration
###############################################################################

def phi_q_regularization_loss(phi_module: LearnablePhi, q_module: LearnableQ, l2_q=1e-5):
    """Return regularization loss for phi and q"""
    loss = 0.0
    if phi_module.orth_reg_weight > 0.0:
        loss = loss + phi_module.orth_reg_weight * phi_module.orth_reg()
    # keep Q weights small (stability)
    loss = loss + l2_q * torch.norm(q_module.linear.weight, p=2)
    return loss


###############################################################################
# Example: integrate with DISTA training:
#   - dataset should yield image patches x_img: (B,1,H,W)
#   - flatten to x_vec = x_img.view(B, -1)
#   - y = Phi(x_vec)
#   - x0 = Q(y)
#   - feed x0 into your DISTA unroll that expects (B,N)
###############################################################################

# Example training loop skeleton (put into your train script)
def train_epoch_learnable_phi_q(
        train_loader,
        model_dista,          # your DISTA unrolled network expecting x0 vector input
        phi_module: LearnablePhi,
        q_module: LearnableQ,
        optimizer_all,
        device,
        epoch,
        cfg
):
    """
    cfg: dict with hyperparams:
      - lambda_rec (float): reconstruction L1/L2 loss weight
      - lambda_sym (float): symmetry / DISTA internal loss weight
      - lambda_reg (float): phi/q regularization weight
      - noise_std (float): add measurement noise during training
    """
    model_dista.train()
    phi_module.train()
    q_module.train()

    for batch in train_loader:
        # assuming batch contains 'img' (B,1,H,W)
        img = batch['img'].to(device)
        B, C, H, W = img.shape
        N = H * W

        x_vec = img.view(B, -1)

        # 1) measurement
        y = phi_module(x_vec, add_noise_std=cfg.get('noise_std', 0.0))  # (B,M)

        # 2) initial reconstruction
        x0 = q_module(y)  # (B,N) or (B,N),(B,1,H,W)

        # 3) pass into DISTA unrolled model
        # model_dista should accept x0 (B,N) and also Phi^T Phi and Phi^T b if used
        # For simplicity, we compute PhiTPhi & PhiTb here (batch-independent matrices)
        # If Phi is learned per-batch, compute accordingly.
        # Build Phi matrix normalized rows if row_norm True
        W = phi_module.weight
        if phi_module.row_norm:
            Wn = W / (torch.norm(W, dim=1, keepdim=True) + 1e-8)
        else:
            Wn = W
        # create PhiTPhi: (N,N) = W^T W
        PhiTPhi = torch.matmul(Wn.t(), Wn)  # (N,N)
        # PhiTb: Phi^T y (batch)
        PhiTb = torch.matmul(y, Wn)  # (B,N) because y (B,M) and Wn (M,N)

        # to model: some DISTA implementations expect (B,N) x, PhiTPhi, PhiTb
        outputs = model_dista(x0, PhiTPhi.to(device), PhiTb.to(device))
        # assume outputs -> [x_pred, symloss]
        x_pred, symloss = outputs[0], outputs[1]

        # reconstruction loss (L1 recommended for sparsity)
        x_pred_img = x_pred.view(B, 1, H, W)
        rec_loss = F.l1_loss(x_pred_img, img)

        # symmetry or other internal losses from DISTA
        sym_loss = torch.mean(symloss**2)

        reg_loss = phi_q_regularization_loss(phi_module, q_module, l2_q=cfg.get('l2_q', 1e-5))

        total_loss = cfg.get('lambda_rec', 1.0) * rec_loss + cfg.get('lambda_sym', 0.1) * sym_loss + cfg.get('lambda_reg', 1.0) * reg_loss

        optimizer_all.zero_grad()
        total_loss.backward()
        optimizer_all.step()

    # optionally return last losses
    return dict(rec_loss=rec_loss.item(), sym_loss=sym_loss.item(), reg_loss=reg_loss.item())


###############################################################################
# Example: create modules, optimizer & scheduler
###############################################################################
def build_learnable_phi_q_experiment(H, W, M, device,
                                     phi_row_norm=True,
                                     phi_orth_reg=1e-3,
                                     q_mode='linear-cnn'):
    N = H * W
    phi = LearnablePhi(N=N, M=M, row_norm=phi_row_norm, orth_reg_weight=phi_orth_reg).to(device)
    q = LearnableQ(N=N, M=M, H=H, W=W, mode=q_mode, hidden=64).to(device)

    # optimizer: use different LR for Phi/Q and DISTA parameters (if you pass model_dista)
    optim = torch.optim.AdamW([
        {'params': phi.parameters(), 'lr': 5e-4, 'weight_decay': 1e-4},
        {'params': q.parameters(), 'lr': 5e-4, 'weight_decay': 1e-4},
    ])

    return phi, q, optim
