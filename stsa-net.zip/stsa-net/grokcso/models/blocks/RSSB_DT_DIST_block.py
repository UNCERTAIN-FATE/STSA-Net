"""
RSSB_DynamicThreshold_DIST_BasicBlock

基于已验证有效的方案三（mAP 0.4674），添加动态阈值生成器

创新点：
1. RSSB全局建模（来自方案三，已验证有效）
2. 动态阈值生成器（DTG）- 根据特征自适应预测软阈值

设计原则：保持简单，不过度设计
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 简化版RSSB（来自方案三，已验证有效）====================

class SimpleRSSB(nn.Module):
    """简化版残差状态空间块 - 已在方案三验证有效"""
    def __init__(self, dim):
        super().__init__()
        
        self.conv1 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.global_conv = nn.Conv2d(dim, dim, 7, 1, 3, groups=dim)
        
        self.channel_mix = nn.Sequential(
            nn.Conv2d(dim, dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(dim * 2, dim, 1)
        )
        
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        x = self.conv1(x)
        x = F.gelu(x)
        x = x + self.global_conv(x)
        x = self.channel_mix(x)
        x = self.conv2(x)
        x = x * self.ca(x)
        return identity + self.gamma * x


# ==================== 创新点2：简化版动态阈值生成器 ====================

class SimpleDynamicThreshold(nn.Module):
    """
    简化版动态阈值生成器
    根据特征统计量预测软阈值，替代固定的soft_thr=0.01
    """
    def __init__(self, channels):
        super().__init__()
        
        # 全局特征提取
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        # 阈值预测（简单的两层MLP）
        self.threshold_pred = nn.Sequential(
            nn.Conv2d(channels, channels // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 4, channels, 1),
            nn.Softplus()  # 确保阈值为正
        )
        
        # 基础阈值
        self.base_threshold = nn.Parameter(torch.tensor(0.01))
        
        # 调制强度
        self.alpha = nn.Parameter(torch.tensor(0.1))
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        返回: (B, C, H, W) 逐通道阈值
        """
        # 全局统计
        global_feat = self.global_pool(x)  # (B, C, 1, 1)
        
        # 预测调制因子
        modulation = self.threshold_pred(global_feat)  # (B, C, 1, 1)
        
        # 动态阈值 = 基础阈值 + 调制
        threshold = self.base_threshold + self.alpha * modulation
        
        # 扩展到空间维度
        threshold = threshold.expand_as(x)
        
        return threshold


# ==================== 主模块 ====================

class RSSB_DT_DIST_BasicBlock(nn.Module):
    """
    RSSB + 动态阈值 DIST BasicBlock
    
    结构：
    - 静态分支（原始设计）
    - RSSB分支（方案三，已验证有效）
    - 动态阈值生成器（新增创新点）
    
    创新点：
    1. RSSB替代动态卷积，提供全局建模能力
    2. 动态阈值生成器，根据特征自适应预测阈值
    """
    def __init__(self, **kwargs):
        super(RSSB_DT_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # ===== 静态分支（保持原设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 【创新点1】RSSB分支（方案三验证有效）=====
        self.mamba_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.mamba_block = SimpleRSSB(64)
        
        # ===== 【创新点2】动态阈值生成器 =====
        self.dynamic_threshold = SimpleDynamicThreshold(64)
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 静态分支 =====
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # ===== RSSB分支 =====
        x_mamba = self.mamba_proj(x_input)
        x_mamba = self.mamba_block(x_mamba)
        
        # ===== 双分支融合 =====
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_mamba
        
        # ===== 【创新点2】动态软阈值 =====
        threshold = self.dynamic_threshold(x_combined)
        x_thresh = torch.sign(x_combined) * F.relu(torch.abs(x_combined) - threshold)
        
        # ===== 后向变换 =====
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 对称损失 =====
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试 ====================

if __name__ == "__main__":
    print("Testing RSSB_DT_DIST_BasicBlock...")
    
    batch_size = 64
    c = 3
    
    block = RSSB_DT_DIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    
    total_params = sum(p.numel() for p in block.parameters())
    print(f"Total parameters: {total_params:,}")
    
    print("Test passed!")