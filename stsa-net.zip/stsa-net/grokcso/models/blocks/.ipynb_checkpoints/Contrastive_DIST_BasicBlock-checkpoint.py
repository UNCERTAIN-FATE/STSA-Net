"""
Contrastive_DIST_BasicBlock: 对比学习增强的DIST模块

核心创新（来自ChatGPT方案4）：
1. 保留原始DISTANet的全部设计（静态+动态分支）
2. 添加对比学习模块，增强目标与背景的可分离性
3. 特征级对比：让重建特征更接近真实目标特征

论文表述：
English: We propose Contrastive-DISTANet, which introduces contrastive learning 
to enhance target-background separability in CSIST unmixing. Our method preserves 
the original dynamic dual-branch architecture while adding a contrastive feature 
learning module. The contrastive loss encourages reconstructed features to be 
similar to ground-truth target features and dissimilar to background features, 
significantly improving separation accuracy for closely-spaced targets.

中文：本文提出对比学习增强的DISTANet（Contrastive-DISTANet），引入对比学习增强
CSIST解混中的目标-背景可分离性。该方法保留原始动态双分支架构，同时添加对比特征
学习模块。对比损失促使重建特征与真实目标特征相似，与背景特征相异，显著提升密集
目标的分离精度。

投稿目标：CVPR/ICCV workshop, ECCV, ICIP
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 创新点1: 特征编码器 ====================

class FeatureEncoder(nn.Module):
    """
    轻量级特征编码器
    将重建结果编码为对比学习所需的特征向量
    """
    def __init__(self, in_channels, feat_dim=64):
        super().__init__()
        
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, 2, 1),  # 下采样
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, 3, 2, 1),  # 再下采样
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(64, feat_dim),
        )
        
        # L2归一化
        self.normalize = True
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        返回: (B, feat_dim) 归一化的特征向量
        """
        feat = self.encoder(x)
        if self.normalize:
            feat = F.normalize(feat, p=2, dim=1)
        return feat


# ==================== 创新点2: 对比损失 ====================

class ContrastiveLoss(nn.Module):
    """
    InfoNCE对比损失
    正样本：重建特征 vs 真实目标特征
    负样本：背景特征
    """
    def __init__(self, temperature=0.1):
        super().__init__()
        self.temperature = temperature
        
    def forward(self, feat_pred, feat_gt, feat_neg=None):
        """
        feat_pred: (B, D) 重建结果的特征
        feat_gt: (B, D) 真实目标的特征
        feat_neg: (B, N, D) 负样本特征（可选，如果没有则用batch内其他样本）
        """
        B, D = feat_pred.shape
        
        # 正样本相似度
        pos_sim = torch.sum(feat_pred * feat_gt, dim=1) / self.temperature  # (B,)
        
        if feat_neg is not None:
            # 使用提供的负样本
            neg_sim = torch.bmm(feat_neg, feat_pred.unsqueeze(-1)).squeeze(-1) / self.temperature
            logits = torch.cat([pos_sim.unsqueeze(1), neg_sim], dim=1)  # (B, 1+N)
        else:
            # 使用batch内其他样本作为负样本
            all_sim = torch.mm(feat_pred, feat_gt.t()) / self.temperature  # (B, B)
            logits = all_sim  # 对角线是正样本
            
        # InfoNCE损失
        labels = torch.zeros(B, dtype=torch.long, device=feat_pred.device)
        loss = F.cross_entropy(logits, labels)
        
        return loss


# ==================== 创新点3: 目标感知增强模块 ====================

class TargetAwareEnhancement(nn.Module):
    """
    目标感知增强模块
    根据对比学习的特征增强目标区域
    """
    def __init__(self, channels):
        super().__init__()
        
        # 注意力生成
        self.attention = nn.Sequential(
            nn.Conv2d(channels, channels // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 4, 1, 1),
            nn.Sigmoid()
        )
        
        # 特征增强
        self.enhance = nn.Sequential(
            nn.Conv2d(channels, channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, 1, 1),
        )
        
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        """
        # 生成目标注意力图
        attn = self.attention(x)  # (B, 1, H, W)
        
        # 增强特征
        enhanced = self.enhance(x)
        
        # 残差增强
        return x + self.gamma * (enhanced * attn)


# ==================== 主模块 ====================

class Contrastive_DIST_BasicBlock(nn.Module):
    """
    对比学习增强的DIST BasicBlock
    
    完全保留原始DISTANet设计：
    - 静态卷积分支 ✓
    - 动态卷积分支 ✓
    - 双分支融合 ✓
    - 软阈值 ✓
    - 对称约束 ✓
    
    创新增强：
    1. 特征编码器 - 提取对比学习特征
    2. 对比损失 - InfoNCE增强目标-背景分离
    3. 目标感知增强 - 根据注意力增强目标区域
    """
    def __init__(self, **kwargs):
        super(Contrastive_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        input_dim = 11 * 11 * c * c
        
        # ===== 静态分支（完全保持原设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 动态分支（完全保持原设计）=====
        self.w1 = nn.Linear(input_dim, 256)
        self.w2 = nn.Linear(256, 9)  # 生成3×3动态卷积核
        
        # ===== 软阈值（保持原设计）=====
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        # ===== 【创新点1】特征编码器 =====
        self.feature_encoder = FeatureEncoder(64, feat_dim=64)
        
        # ===== 【创新点2】对比损失 =====
        self.contrastive_loss = ContrastiveLoss(temperature=0.1)
        
        # ===== 【创新点3】目标感知增强 =====
        self.target_enhance = TargetAwareEnhancement(64)
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
        # 存储对比损失
        self.current_contrastive_loss = None
        
    def forward(self, x, PhiTPhi, PhiTb, gt=None):
        """
        x: 输入
        PhiTPhi, PhiTb: ISTA参数
        gt: 真实目标（训练时提供，用于对比学习）
        """
        # 保存原始输入用于动态分支
        x_original = x
        
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 静态分支 =====
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # ===== 动态分支（完全保持原设计）=====
        x_dyn = self.w1(x_original)
        x_dyn = F.relu(x_dyn)
        weights = self.w2(x_dyn)
        weights = weights.view(-1, 1, 3, 3)
        
        # 逐样本动态卷积
        B = x_input.size(0)
        x_dynamic_list = []
        for i in range(B):
            out = F.conv2d(x_input[i:i+1], weights[i:i+1], padding=1)
            x_dynamic_list.append(out)
        x_dynamic = torch.cat(x_dynamic_list, dim=0)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 扩展到64通道
        x_dynamic = x_dynamic.expand(-1, 64, -1, -1)
        
        # ===== 双分支融合 =====
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_dynamic
        
        # ===== 【创新点3】目标感知增强 =====
        x_enhanced = self.target_enhance(x_combined)
        
        # ===== 【创新点1&2】对比学习（仅训练时）=====
        if gt is not None and self.training:
            # 编码重建特征
            feat_pred = self.feature_encoder(x_enhanced)
            
            # 编码真实目标特征
            gt_reshaped = gt.view(-1, 1, 11 * self.c, 11 * self.c)
            gt_feat_map = F.conv2d(gt_reshaped, self.conv1_forward, padding=1)
            gt_feat_map = F.relu(gt_feat_map)
            gt_feat_map = F.conv2d(gt_feat_map, self.conv2_forward, padding=1)
            feat_gt = self.feature_encoder(gt_feat_map)
            
            # 计算对比损失
            self.current_contrastive_loss = self.contrastive_loss(feat_pred, feat_gt)
        else:
            self.current_contrastive_loss = torch.tensor(0.0, device=x.device)
        
        # ===== 软阈值 =====
        x_thresh = torch.mul(
            torch.sign(x_enhanced), 
            F.relu(torch.abs(x_enhanced) - self.soft_thr)
        )
        
        # ===== 后向变换 =====
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 对称损失 =====
        x_sym = F.conv2d(x_enhanced, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]
    
    def get_contrastive_loss(self):
        """获取对比损失（需要添加到总损失中）"""
        return self.current_contrastive_loss


# ==================== 不需要gt的简化版本 ====================

class ContrastiveSimple_DIST_BasicBlock(nn.Module):
    """
    简化版对比学习DIST（不需要额外传入gt）
    
    使用自对比：同一batch内的样本互为正负样本
    """
    def __init__(self, **kwargs):
        super(ContrastiveSimple_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        input_dim = 11 * 11 * c * c
        
        # ===== 静态分支 =====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 动态分支 =====
        self.w1 = nn.Linear(input_dim, 256)
        self.w2 = nn.Linear(256, 9)
        
        # ===== 软阈值 =====
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        # ===== 【创新点】目标感知增强 =====
        self.target_enhance = TargetAwareEnhancement(64)
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x_original = x
        
        # ISTA步骤
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # 动态分支
        x_dyn = self.w1(x_original)
        x_dyn = F.relu(x_dyn)
        weights = self.w2(x_dyn)
        weights = weights.view(-1, 1, 3, 3)
        
        B = x_input.size(0)
        x_dynamic_list = []
        for i in range(B):
            out = F.conv2d(x_input[i:i+1], weights[i:i+1], padding=1)
            x_dynamic_list.append(out)
        x_dynamic = torch.cat(x_dynamic_list, dim=0)
        x_dynamic = torch.sigmoid(x_dynamic)
        x_dynamic = x_dynamic.expand(-1, 64, -1, -1)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_dynamic
        
        # 目标感知增强
        x_enhanced = self.target_enhance(x_combined)
        
        # 软阈值
        x_thresh = torch.mul(
            torch.sign(x_enhanced), 
            F.relu(torch.abs(x_enhanced) - self.soft_thr)
        )
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_enhanced, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试 ====================

if __name__ == "__main__":
    print("Testing ContrastiveSimple_DIST_BasicBlock...")
    
    batch_size = 64
    c = 3
    
    block = ContrastiveSimple_DIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    
    total_params = sum(p.numel() for p in block.parameters())
    print(f"Total parameters: {total_params:,}")
    
    print("Test passed!")