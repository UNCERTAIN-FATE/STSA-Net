# -*- coding: utf-8 -*-
# grokcso/models/blocks/dista_mamba_learnable.py
"""
终极 SOTA 版本：DISTA + Mamba + DINO + Learnable Φ & Q
修正版：修复 lambda_step 定义、PhiTb 设备转移、N/reshape 不一致等问题
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import timm
from mamba_ssm import Mamba
from ..tricks.attention_block import LSKmodule
from .phi_q import LearnablePhi, LearnableQ
from mmengine.registry import MODELS

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class DinoMambaGammaFixed(nn.Module):
    def __init__(self, dino_dim=768, hidden_dim=128, heads=3):
        super().__init__()
        self.pre = nn.Sequential(
            nn.Conv2d(dino_dim, hidden_dim, 1),
            nn.ReLU(inplace=True)
        )
        self.mamba = Mamba(d_model=hidden_dim, d_state=16, d_conv=3)
        self.post = nn.Sequential(
            nn.Conv2d(hidden_dim, heads, 1),
            nn.Tanh()
        )

    def forward(self, x):
        B, C, H, W = x.shape
        h = self.pre(x)
        seq = h.flatten(2).transpose(1, 2)
        seq_out = self.mamba(seq)
        out = seq_out.transpose(1, 2).reshape(B, -1, H, W)
        gamma_heads = self.post(out)
        gamma = gamma_heads.sum(dim=1, keepdim=True)
        return torch.tanh(gamma)  # (-1,1)


@MODELS.register_module()
class DISTA_MambaBlock_Learnable(nn.Module):
    def __init__(self, c=3, lambda_weight=0.5,
                 dino_ckpt="/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth",
                 alpha=0.10, gamma_heads=3, gamma_hidden=128,
                 tau_min=1e-4, tau_max=0.06,
                 learn_phi_q=False, sampling_rate=0.3,
                 Phi_data_Name=None, Qinit_Name=None):
        super().__init__()
        self.c = c
        self.patch_base = 11
        self.H = self.patch_base * self.c
        self.W = self.patch_base * self.c
        self.N = (self.H) * (self.W)
        self.M = int(self.N * sampling_rate)
        self.learn_phi_q = bool(learn_phi_q)
        # lambda_weight kept as tensor (original code used it)
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        # iterative step parameter
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))

        # ==================== 可学习 Φ 和 Q ====================
        if self.learn_phi_q:
            self.Phi = LearnablePhi(N=self.N, M=self.M, row_norm=True, orth_reg_weight=1e-3)
            self.Q = LearnableQ(N=self.N, M=self.M, H=self.H, W=self.W, mode='linear-cnn', hidden=64)

            if Phi_data_Name and Qinit_Name:
                # 尝试加载 mat 中的多种 key（兼容不同命名）
                import scipy.io
                mat_phi = scipy.io.loadmat(Phi_data_Name)
                mat_q = scipy.io.loadmat(Qinit_Name)

                # phi key candidates
                phi_keys = ['Phi', 'phi', 'A', 'Phi_init']
                q_keys = ['Q', 'Qinit', 'Q_init', 'Q0']

                phi_init = None
                for k in phi_keys:
                    if k in mat_phi:
                        phi_init = torch.from_numpy(mat_phi[k]).float()
                        break

                q_init = None
                for k in q_keys:
                    if k in mat_q:
                        q_init = torch.from_numpy(mat_q[k]).float()
                        break

                with torch.no_grad():
                    if phi_init is not None and phi_init.shape == self.Phi.weight.shape:
                        self.Phi.weight.copy_(phi_init.to(self.Phi.weight.device))
                    elif phi_init is not None:
                        ph = self.Phi.weight
                        ph.data.zero_()
                        min_r = min(ph.shape[0], phi_init.shape[0])
                        min_c = min(ph.shape[1], phi_init.shape[1])
                        ph.data[:min_r, :min_c].copy_(phi_init[:min_r, :min_c].to(ph.device))

                    if hasattr(self.Q, 'linear') and q_init is not None:
                        qw = self.Q.linear.weight  # shape (N, M)
                        if q_init.shape == qw.shape:
                            qw.copy_(q_init.to(qw.device))
                        else:
                            qw.data.zero_()
                            min_r = min(qw.shape[0], q_init.shape[0])
                            min_c = min(qw.shape[1], q_init.shape[1])
                            qw.data[:min_r, :min_c].copy_(q_init[:min_r, :min_c].to(qw.device))
        else:
            self.Phi = None
            self.Q = None

        # ==================== DINO + Mamba + Conv ====================
        # create DINO backbone (keeps as eval, frozen)
        self.dino = timm.create_model(
            'vit_base_patch14_dinov2.lvd142m', pretrained=False, num_classes=0, global_pool=''
        )
        state = torch.load(dino_ckpt, map_location='cpu')
        # load_state may not be strict
        self.dino.load_state_dict(state, strict=False)
        self.dino.eval()
        for p in self.dino.parameters():
            p.requires_grad = False

        # conv params kept as nn.Parameter (you used conv weights directly)
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        self.theta_local = LSKmodule(64)
        self.gamma_mod = DinoMambaGammaFixed(dino_dim=768, hidden_dim=gamma_hidden, heads=gamma_heads)

        self.alpha = float(alpha)
        self.tau_min = float(tau_min)
        self.tau_max = float(tau_max)

        # 注册到 device
        self.to(device)

    def run_dino(self, x_3ch):
        # x_3ch: (B,3,Hp,Wp)
        with torch.no_grad():
            proj = self.dino.patch_embed.proj(x_3ch)
            B, D, Hp, Wp = proj.shape
            tokens = proj.flatten(2).transpose(1, 2)
            cls_token = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls_token, tokens), dim=1)

            pos = self.dino.pos_embed
            orig_N = pos.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))
            pos_spatial = pos[:, 1:, :].transpose(1, 2).reshape(1, D, orig_H, orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp, Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1, D, Hp * Wp).transpose(1, 2)
            pos_all = torch.cat([pos[:, 0:1, :], pos_up], dim=1).to(x_tokens.device)

            x_tokens = x_tokens + pos_all
            x_tokens = self.dino.pos_drop(x_tokens)
            for blk in self.dino.blocks:
                x_tokens = blk(x_tokens)
            x_tokens = self.dino.norm(x_tokens)

        spatial = x_tokens[:, 1:, :].transpose(1, 2).reshape(B, D, Hp, Wp)
        return spatial

    def forward(self, x, PhiTPhi=None, PhiTb=None):
        """
        x: (B, N) or (B, N, 1)
        returns: [x_pred (B,N), symloss (B,1,H,W)]
        """
        # handle both (B,N) or (B,N,1)
        if x.dim() == 3 and x.size(2) == 1:
            B, N, _ = x.shape
            x_vec = x
        elif x.dim() == 2:
            B, N = x.shape
            x_vec = x.view(B, N, 1)
        else:
            raise ValueError("x should be (B,N) or (B,N,1)")

        if N != self.N:
            raise ValueError(f"Input dimension N={N} doesn't match module N={self.N}")

        # compute PhiTPhi / PhiTb if learnable
        if self.learn_phi_q:
            W = self.Phi.weight.to(x_vec.device)   # (M, N)
            Wn = W / (torch.norm(W, dim=1, keepdim=True) + 1e-8)  # normalized copy
            PhiTPhi = torch.matmul(Wn.t(), Wn).to(x_vec.device)   # (N,N)

            # y = Phi(x)
            y = F.linear(x_vec.squeeze(-1), Wn)  # (B, M)
            PhiTb = torch.matmul(y, Wn).unsqueeze(-1)  # (B,N,1)
        else:
            if PhiTPhi is None or PhiTb is None:
                raise ValueError("Static mode needs PhiTPhi and PhiTb")
            PhiTPhi = PhiTPhi.to(x_vec.device)
            if PhiTb.dim() == 2:
                PhiTb = PhiTb.to(x_vec.device).unsqueeze(-1)
            else:
                PhiTb = PhiTb.to(x_vec.device)

        # ISTA-ish step (batch)
        grad = torch.matmul(PhiTPhi, x_vec)   # (B, N, 1)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb
        x = x_vec.view(B, -1)  # (B, N)

        # denoise / threshold pipeline (as your original)
        x_1ch = x.view(B, 1, self.H, self.W)
        x_3ch = x_1ch.repeat(1, 3, 1, 1)

        # forward conv (using conv params stored in nn.Parameter)
        h = F.conv2d(x_1ch, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)

        theta_local = self.theta_local(x_forward)

        spatial = self.run_dino(x_3ch)
        spatial_up = F.interpolate(spatial, size=x_forward.shape[2:], mode='bilinear', align_corners=False)
        gamma = self.gamma_mod(spatial_up)

        theta_final = theta_local + self.alpha * gamma
        theta_final = torch.clamp(theta_final, min=self.tau_min, max=self.tau_max)

        x_thresh = torch.sign(x_forward) * F.relu(torch.abs(x_forward) - theta_final)

        # backward conv
        h2 = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)

        # symmetry loss (reconstruction consistency)
        h_est = F.conv2d(x_forward, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_1ch

        return [x_pred, symloss]

    # ----------------------------
    # MMEngine 接口（MMEngine v2.x）
    # ----------------------------
    def train_step(self, data, optim_wrapper):
        # 修复：你的数据集返回的图像是 'gt_img_11'
        img = data.get('gt_img_11')
        if img is None:
            raise KeyError(f"train_step 找不到图像！keys: {list(data.keys())}")
    
        if isinstance(img, list):
            img = torch.stack(img, dim=0)
       # img = img.to(self.device)  # (B,1,H,W)

        if img.dim() == 4:
            if img.shape[2] == 1 and img.shape[3] == self.N:  # (B,1,1,N)
                img = img.squeeze(2)  # (B,1,N)
            elif img.shape[1] == 1 and img.shape[2] == self.H and img.shape[3] == self.W:
                pass  # (B,1,H,W) 完美
            else:
                raise ValueError(f"不支持的图像形状: {img.shape}")
        elif img.dim() == 3:
            if img.shape[1] == 1 and img.shape[2] == self.N:  # (B,1,N)
                pass
            elif img.shape[1] == self.N:  # (B,N)
                img = img.unsqueeze(1)  # (B,1,N)
            else:
                raise ValueError(f"不支持的图像形状: {img.shape}")
        else:
            raise ValueError(f"不支持的图像维度: {img.dim()}")

        # 最终统一为 (B,1,H,W)
        if img.shape[2] != self.H or img.shape[3] != self.W:
            img = img.view(img.shape[0], 1, self.H, self.W)

        B, C, H, W = img.shape
        assert C == 1 and H == self.H and W == self.W, f"最终图像尺寸不匹配: {img.shape}"

        # 展平为向量
        x_vec = img.view(B, -1)  # (B, N)

        # 前向传播
        x_pred, symloss = self(x_vec)

        # 计算损失
        x_pred_img = x_pred.view(B, 1, H, W)
        rec_loss = F.l1_loss(x_pred_img, img)
        sym_loss = torch.mean(symloss ** 2)

        total_loss = rec_loss + 0.1 * sym_loss
        if self.learn_phi_q:
            reg_loss = phi_q_regularization_loss(self.Phi, self.Q)
            total_loss = total_loss + reg_loss

        parsed_losses = self.parse_losses(dict(loss=total_loss))
        optim_wrapper.update_params(parsed_losses)
        return parsed_losses



    def val_step(self, data):
        img = data.get('gt_img_11', data.get('img'))
        if img is None:
            raise KeyError(f"val_step 找不到图像！keys: {list(data.keys())}")
        if isinstance(img, list):
            img = torch.stack(img, dim=0)
       # img = img.to(self.device)
    
        with torch.no_grad():
            x_vec = img.view(img.shape[0], -1)
            x_pred, _ = self(x_vec)
            x_pred_img = x_pred.view_as(img)
        return {'pred': x_pred_img, 'gt': img}

    def test_step(self, data):
        return self.val_step(data)
