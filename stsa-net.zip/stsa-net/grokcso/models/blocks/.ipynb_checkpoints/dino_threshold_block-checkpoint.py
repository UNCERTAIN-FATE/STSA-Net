# paste into grokcso/models/blocks/dino_threshold_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import math
import timm

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class DinoThresholdBlock(nn.Module):
    """
    保留 DISTA 的 CNN-based threshold 主路径（稳定）
    用 DINOv2 提取的语义/上下文特征生成一个小的 modulation map gamma，
    最终阈值 = clamp(theta_cnn * (1 + alpha * gamma), tau_min, tau_max)
    """
    def __init__(self, c=1, lambda_weight=0.5,
                 dino_ckpt="/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth",
                 alpha=0.1, tau_min=1e-4, tau_max=0.06):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)

        # forward / backward convs (same shape as original)
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))

        # CNN-based small threshold decoder (local, stable)
        self.th_cnn_decoder = nn.Sequential(
            nn.Conv2d(64, 32, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=1),
            nn.Sigmoid()
        )

        # DINOv2 backbone (frozen by default)
        # use timm model name similar to your env -- adjust if different
        self.dino = timm.create_model('vit_base_patch14_dinov2.lvd142m', pretrained=False, num_classes=0, global_pool='')
        state = torch.load(dino_ckpt, map_location='cpu')
        self.dino.load_state_dict(state, strict=False)
        self.dino.eval()
        for p in self.dino.parameters():
            p.requires_grad = False

        # small head to turn dino spatial features -> modulation map gamma (range approx [-1,1])
        self.gamma_proj = nn.Sequential(
            nn.Conv2d(768, 256, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 64, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, 1),
            # we will normalize / scale later
        )

        # hyperparams for modulation
        self.alpha = alpha
        self.tau_min = tau_min
        self.tau_max = tau_max

    def _dino_spatial(self, x_3ch, target_size):
        """
        Extract DINO spatial features robustly:
        - Upsample input to nearest multiple of patch size (14) or at least 56
        - Run patch_embed + transformer blocks (frozen)
        - Restore spatial map to target_size by interpolation
        """
        B = x_3ch.shape[0]
        _, _, H, W = x_3ch.shape
        patch_size = self.dino.patch_embed.patch_size if hasattr(self.dino.patch_embed, 'patch_size') else 14
        patch_size = patch_size[0] if isinstance(patch_size, (tuple, list)) else patch_size

        # choose upscale size: at least patch_size*4 for some spatial resolution
        min_side = max(patch_size*4, patch_size * math.ceil(max(H, W) / patch_size))
        up_h = int(math.ceil(H / patch_size) * patch_size)
        up_w = int(math.ceil(W / patch_size) * patch_size)
        up_h = max(up_h, min_side)
        up_w = max(up_w, min_side)

        x_up = F.interpolate(x_3ch, size=(up_h, up_w), mode='bilinear', align_corners=False)  # [B,3,Hu,Vu]

        # compute patch projection + tokens similar to dinov2 forward (no grad)
        with torch.no_grad():
            proj = self.dino.patch_embed.proj(x_up)  # [B, D, Hp, Wp]
            Bp, D, Hp, Wp = proj.shape
            tokens = proj.flatten(2).transpose(1,2)  # [B, N, D]
            cls_token = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls_token, tokens), dim=1)
            pos_embed = self.dino.pos_embed
            orig_N = pos_embed.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))
            pos_spatial = pos_embed[:,1:,:].transpose(1,2).reshape(1, D, orig_H, orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp, Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1, D, Hp*Wp).transpose(1,2)
            pos_cls = pos_embed[:,0:1,:]
            pos = torch.cat([pos_cls, pos_up], dim=1).to(x_tokens.device)
            x_tokens = x_tokens + pos
            x_tokens = self.dino.pos_drop(x_tokens)

            xt = x_tokens
            for blk in self.dino.blocks:
                xt = blk(xt)
            xt = self.dino.norm(xt)  # [B, N+1, D]

        spatial_tokens = xt[:,1:,:]                 # [B, N, D]
        spatial = spatial_tokens.transpose(1,2).reshape(B, D, Hp, Wp)
        spatial_up = F.interpolate(spatial, size=target_size, mode='bilinear', align_corners=False)  # [B,D,Ht,Wt]
        return spatial_up  # tensor [B, D, Ht, Wt]

    def forward(self, x, PhiTPhi, PhiTb):
        """
        x: [B, N] vectorized patch (N = 11*c * 11*c)
        PhiTPhi: [B, N, N] or [N,N] (handle both)
        PhiTb: [B, N] or [N] (handle both)
        returns: [x_pred, symloss]
        """
        B = x.shape[0]
        N = x.shape[1]

        # gradient step (vectorized)
        x_vec = x.view(B, N, 1)
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)

        # reshape to image
        H = 11 * self.c
        x_img = x.view(B, 1, H, H)
        x_3ch = x_img.repeat(1, 3, 1, 1)

        # forward conv (local)
        h = F.conv2d(x_img, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)  # [B,64,H,W]

        # compute cnn-based base theta (local, stable)
        theta_cnn = self.th_cnn_decoder(x_forward)  # [B,1,H,W], in (0,1)
        # rescale to small typical thresholds range (tuneable)
        theta_cnn = theta_cnn * 0.03  # base scale (empirical), you can tune

        # compute DINO spatial features (robust extraction)
        spatial_feat = self._dino_spatial(x_3ch, target_size=x_forward.shape[2:])  # [B, D, H, W], D=768
        gamma_raw = self.gamma_proj(spatial_feat)  # [B,1,H,W], unbounded

        # normalize gamma to zero-mean small-range map
        gamma_mean = gamma_raw.mean(dim=[2,3], keepdim=True)
        gamma = (gamma_raw - gamma_mean)
        # tanh to bound, then small scale
        gamma = torch.tanh(gamma)  # in (-1,1)
        # final modulation factor (small)
        # theta_final = clamp(theta_cnn * (1 + alpha * gamma), tau_min, tau_max)
        theta_mod = 1.0 + self.alpha * gamma
        theta = theta_cnn * theta_mod
        theta = torch.clamp(theta, min=self.tau_min, max=self.tau_max)

        # soft-threshold (apply per-pixel)
        x_thr = torch.sign(x_forward) * F.relu(torch.abs(x_forward) - theta)

        # backward conv
        h2 = F.conv2d(x_thr, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)

        # symmetry loss (approx Q(P(x)) - x)
        h_est = F.conv2d(x_forward, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_img

        return [x_pred, symloss]
