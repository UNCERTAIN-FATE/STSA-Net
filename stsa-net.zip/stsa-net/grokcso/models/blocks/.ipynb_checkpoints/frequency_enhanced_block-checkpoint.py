# paste into grokcso/models/blocks/frequency_enhanced_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class FrequencyAttention(nn.Module):
    """频域注意力模块 - 在频域进行特征增强"""
    def __init__(self, channels=64):
        super().__init__()
        self.channels = channels
        
        # 频域特征处理
        self.freq_conv = nn.Sequential(
            nn.Conv2d(channels*2, channels, 1),  # *2 because of real and imag parts
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 1),
            nn.Sigmoid()
        )
        
        # 空间域增强
        self.spatial_conv = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1)
        )
        
    def forward(self, x):
        B, C, H, W = x.shape
        
        # FFT到频域
        x_freq = torch.fft.rfft2(x, norm='ortho')
        x_real = x_freq.real
        x_imag = x_freq.imag
        
        # 拼接实部和虚部
        x_freq_cat = torch.cat([x_real, x_imag], dim=1)
        
        # 频域注意力
        freq_attention = self.freq_conv(x_freq_cat)
        
        # 应用注意力到实部和虚部
        x_real_weighted = x_real * freq_attention
        x_imag_weighted = x_imag * freq_attention
        
        # 重构复数
        x_freq_weighted = torch.complex(x_real_weighted, x_imag_weighted)
        
        # IFFT回空间域
        x_enhanced = torch.fft.irfft2(x_freq_weighted, s=(H, W), norm='ortho')
        
        # 空间域进一步增强
        x_spatial = self.spatial_conv(x_enhanced)
        
        return x_spatial + x

class DynamicFilterBank(nn.Module):
    """动态滤波器组 - 根据输入自适应生成滤波器"""
    def __init__(self, in_channels=64, num_filters=4):
        super().__init__()
        self.num_filters = num_filters
        self.in_channels = in_channels
        
        # 滤波器参数生成网络
        self.param_net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels//2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels//2, num_filters * 2, 1)  # 生成每个滤波器的中心频率和带宽
        )
        
        # 特征融合
        self.fusion = nn.Sequential(
            nn.Conv2d(in_channels * num_filters, in_channels, 1),
            nn.ReLU(inplace=True)
        )
        
    def create_gaussian_filter(self, center, bandwidth, size):
        """创建高斯频域滤波器"""
        H, W = size
        y = torch.arange(0, H, dtype=torch.float32, device=center.device) - H // 2
        x = torch.arange(0, W, dtype=torch.float32, device=center.device) - W // 2
        y, x = torch.meshgrid(y, x, indexing='ij')
        
        # 频率距离
        freq_dist = torch.sqrt(x**2 + y**2)
        
        # 高斯滤波器
        sigma = bandwidth.clamp(min=1.0)
        gaussian = torch.exp(-((freq_dist - center.clamp(min=0)) ** 2) / (2 * sigma ** 2))
        
        return gaussian
        
    def forward(self, x):
        B, C, H, W = x.shape
        
        # 生成滤波器参数
        params = self.param_net(x).view(B, self.num_filters, 2)  # [B, num_filters, 2]
        
        # 对每个样本应用不同的滤波器组
        filtered_features = []
        for i in range(self.num_filters):
            center = torch.sigmoid(params[:, i, 0]) * min(H, W) / 2  # [B]
            bandwidth = torch.sigmoid(params[:, i, 1]) * min(H, W) / 4 + 1  # [B]
            
            # 对batch中每个样本
            batch_filtered = []
            for b in range(B):
                # FFT
                x_freq = torch.fft.fft2(x[b], norm='ortho')
                x_freq_shifted = torch.fft.fftshift(x_freq)
                
                # 应用高斯滤波器
                gaussian_filter = self.create_gaussian_filter(center[b], bandwidth[b], (H, W))
                gaussian_filter = gaussian_filter.unsqueeze(0).expand(C, -1, -1)
                
                x_filtered = x_freq_shifted * gaussian_filter
                x_filtered = torch.fft.ifftshift(x_filtered)
                x_spatial = torch.fft.ifft2(x_filtered, norm='ortho').real
                
                batch_filtered.append(x_spatial)
            
            filtered_features.append(torch.stack(batch_filtered, dim=0))
        
        # 融合所有滤波器的输出
        filtered_concat = torch.cat(filtered_features, dim=1)
        output = self.fusion(filtered_concat)
        
        return output

class FrequencyEnhancedBlock(nn.Module):
    """频域增强模块 - 结合频域处理和动态滤波"""
    def __init__(self, c=1, lambda_weight=0.5, **kwargs):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        
        # 基础卷积
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        # 动态卷积
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 频域注意力
        self.freq_attention = FrequencyAttention(channels=64)
        
        # 动态滤波器组
        self.filter_bank = DynamicFilterBank(in_channels=64, num_filters=3)
        
        # 阈值网络
        self.threshold_net = nn.Sequential(
            nn.Conv2d(64, 32, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]
        minor = x
        
        # 梯度步
        x_vec = x.view(B, N, 1)
        if PhiTPhi.dim() == 2:
            PhiTPhi = PhiTPhi.unsqueeze(0).expand(B, -1, -1)
        if PhiTb.dim() == 1:
            PhiTb = PhiTb.unsqueeze(0).expand(B, -1)
        
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)
        
        H = 11 * self.c
        x_input = x.view(B, 1, H, H)
        
        # 前向卷积
        h = F.conv2d(x_input, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)
        
        # 频域注意力增强
        x_freq_enhanced = self.freq_attention(x_forward)
        
        # 动态滤波器组
        x_filtered = self.filter_bank(x_freq_enhanced)
        
        # 特征融合
        x_combined = x_forward + x_freq_enhanced + x_filtered
        
        # 动态卷积分支
        minor = self.w1(minor)
        weights = self.w2(minor)
        weights = weights.reshape(B, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 双路融合
        x_fused = self.lambda_weight * x_combined + (1 - self.lambda_weight) * x_dynamic
        
        # 自适应阈值
        threshold = self.threshold_net(x_fused) * 0.06 + 0.001
        x_thresholded = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # 后向卷积
        h2 = F.conv2d(x_thresholded, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)
        
        # 对称损失
        h_est = F.conv2d(x_combined, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]