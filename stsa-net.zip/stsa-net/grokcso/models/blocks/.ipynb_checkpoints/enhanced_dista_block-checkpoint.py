# paste into grokcso/models/blocks/enhanced_dista_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class ImprovedLSKAttention(nn.Module):
    """改进的LSK注意力 - 增强大核选择性"""
    def __init__(self, dim=64):
        super().__init__()
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        self.conv_spatial = nn.Conv2d(dim, dim, 7, stride=1, padding=9, groups=dim, dilation=3)
        self.conv1 = nn.Conv2d(dim, dim//2, 1)
        self.conv2 = nn.Conv2d(dim, dim//2, 1)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim//2, dim, 1)
        
        # 额外的通道注意力
        self.channel_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim//4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim//4, dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x):   
        attn1 = self.conv0(x)
        attn2 = self.conv_spatial(attn1)

        attn1 = self.conv1(attn1)
        attn2 = self.conv2(attn2)
        
        attn = torch.cat([attn1, attn2], dim=1)
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn = attn1 * sig[:,0,:,:].unsqueeze(1) + attn2 * sig[:,1,:,:].unsqueeze(1)
        attn = self.conv(attn)
        
        # 添加通道注意力
        ch_att = self.channel_att(x)
        attn = attn * ch_att
        
        return attn

class FeatureRefinementBlock(nn.Module):
    """特征细化模块 - 多尺度特征提取和融合"""
    def __init__(self, channels=64):
        super().__init__()
        
        # 多尺度卷积
        self.branch1 = nn.Sequential(
            nn.Conv2d(channels, channels//2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//2, channels//2, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.branch2 = nn.Sequential(
            nn.Conv2d(channels, channels//2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//2, channels//2, 3, padding=2, dilation=2),
            nn.ReLU(inplace=True)
        )
        
        # 融合
        self.fusion = nn.Sequential(
            nn.Conv2d(channels, channels, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1)
        )
        
    def forward(self, x):
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        feat = torch.cat([b1, b2], dim=1)
        out = self.fusion(feat)
        return out + x

class EnhancedDynamicConv(nn.Module):
    """增强的动态卷积 - 改进权重生成"""
    def __init__(self, in_features, out_features=9):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_features, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(512, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, out_features)
        )
        
    def forward(self, x):
        return self.net(x)

class AdaptiveThresholdLearner(nn.Module):
    """自适应阈值学习器 - 基于LSK注意力的改进版"""
    def __init__(self, channels=64):
        super().__init__()
        self.lsk_att = ImprovedLSKAttention(dim=channels)
        
        # 额外的阈值细化
        self.refine = nn.Sequential(
            nn.Conv2d(channels, 32, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, 1),
            nn.Sigmoid()
        )
        
        # 可学习的阈值缩放因子
        self.scale = nn.Parameter(torch.ones(1) * 0.05)
        self.bias = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        # LSK注意力作为基础
        att = self.lsk_att(x)
        
        # 细化阈值
        threshold = self.refine(x)
        
        # 结合注意力和细化阈值
        combined = att * threshold
        
        # 缩放到合适范围
        threshold_final = torch.abs(self.scale) * combined + torch.abs(self.bias) + 1e-5
        threshold_final = torch.clamp(threshold_final, min=1e-5, max=0.1)
        
        return threshold_final

class EnhancedDISTABlock(nn.Module):
    """增强版DISTA模块 - 轻量级改进"""
    def __init__(self, c=1, lambda_weight=0.5, **kwargs):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        
        # 基础卷积（保留原始设计）
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        # 增强的动态卷积生成
        self.dynamic_conv_gen = EnhancedDynamicConv(11*11*c*c, out_features=9)
        
        # 特征细化模块
        self.feature_refine = FeatureRefinementBlock(channels=64)
        
        # 改进的阈值学习器
        self.threshold_learner = AdaptiveThresholdLearner(channels=64)
        
        # 残差连接的权重
        self.alpha = nn.Parameter(torch.ones(1) * 0.2)
        
    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]
        minor = x.clone()
        
        # 梯度步
        x_vec = x.view(B, N, 1)
        if PhiTPhi.dim() == 2:
            PhiTPhi = PhiTPhi.unsqueeze(0).expand(B, -1, -1)
        if PhiTb.dim() == 1:
            PhiTb = PhiTb.unsqueeze(0).expand(B, -1)
        
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)
        
        H = 11 * self.c
        x_input = x.view(B, 1, H, H)
        
        # 前向卷积路径
        h = F.conv2d(x_input, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)
        
        # 特征细化
        x_forward_refined = self.feature_refine(x_forward)
        
        # 动态卷积路径（增强版）
        weights = self.dynamic_conv_gen(minor)
        weights = weights.reshape(B, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 双路融合（带残差）
        x_fused = self.lambda_weight * x_forward_refined + (1 - self.lambda_weight) * x_dynamic
        x_fused = x_fused + self.alpha * x_forward  # 添加原始特征的残差
        
        # 自适应阈值
        threshold = self.threshold_learner(x_fused)
        x_thresholded = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # 后向卷积
        h2 = F.conv2d(x_thresholded, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)
        
        # 对称损失
        h_est = F.conv2d(x_forward_refined, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]