"""
DynamicEnhanced_DIST_BasicBlock: 动态增强版DIST模块

核心：保留原始动态卷积机制，在此基础上增强

创新点：
1. 动态多尺度卷积 - 同时生成3×3和5×5动态卷积核
2. 动态阈值生成器(DTG) - 根据特征自适应预测软阈值
3. 特征细化模块 - 增强小目标检测能力

论文表述：
English: We propose DynamicEnhanced-DISTANet with three key innovations: 
(1) Dynamic Multi-scale Convolution that generates both 3×3 and 5×5 kernels 
adaptively based on input features, enabling multi-scale sparse pattern capture;
(2) Dynamic Threshold Generator (DTG) that predicts pixel-wise soft thresholds 
conditioned on feature statistics, replacing the fixed global threshold;
(3) Feature Refinement Module that preserves high-frequency details for 
improved small target detection.

中文：本文提出动态增强DISTANet，包含三个核心创新：
(1) 动态多尺度卷积 - 根据输入特征自适应生成3×3和5×5卷积核，捕获多尺度稀疏模式；
(2) 动态阈值生成器(DTG) - 根据特征统计量预测逐像素软阈值，替代固定全局阈值；
(3) 特征细化模块 - 保留高频细节，提升小目标检测能力。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 创新点1: 动态多尺度卷积 ====================

class DynamicMultiScaleConv(nn.Module):
    """
    动态多尺度卷积模块
    根据输入动态生成3×3和5×5两种尺度的卷积核
    """
    def __init__(self, input_dim, hidden_dim=256):
        super().__init__()
        
        # 特征编码
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
        )
        
        # 动态生成3×3卷积核 (1个输入通道，1个输出通道)
        self.weight_3x3 = nn.Linear(hidden_dim, 1 * 1 * 3 * 3)  # 9个参数
        
        # 动态生成5×5卷积核
        self.weight_5x5 = nn.Linear(hidden_dim, 1 * 1 * 5 * 5)  # 25个参数
        
        # 尺度融合权重（可学习）
        self.scale_fusion = nn.Linear(hidden_dim, 2)
        
    def forward(self, x_flat, x_2d):
        """
        x_flat: (B, input_dim) 用于生成动态权重
        x_2d: (B, 1, H, W) 用于卷积
        """
        B = x_flat.size(0)
        
        # 编码特征
        feat = self.encoder(x_flat)
        
        # 生成动态卷积核
        w3 = self.weight_3x3(feat).view(B, 1, 1, 3, 3)  # (B, out, in, 3, 3)
        w5 = self.weight_5x5(feat).view(B, 1, 1, 5, 5)  # (B, out, in, 5, 5)
        
        # 生成融合权重
        scale_w = torch.softmax(self.scale_fusion(feat), dim=-1)  # (B, 2)
        
        # 逐样本动态卷积
        out_3x3_list = []
        out_5x5_list = []
        
        for i in range(B):
            # 3×3动态卷积
            out_3 = F.conv2d(x_2d[i:i+1], w3[i], padding=1)
            out_3x3_list.append(out_3)
            
            # 5×5动态卷积
            out_5 = F.conv2d(x_2d[i:i+1], w5[i], padding=2)
            out_5x5_list.append(out_5)
        
        out_3x3 = torch.cat(out_3x3_list, dim=0)  # (B, 1, H, W)
        out_5x5 = torch.cat(out_5x5_list, dim=0)  # (B, 1, H, W)
        
        # 多尺度融合
        out = scale_w[:, 0:1, None, None] * out_3x3 + \
              scale_w[:, 1:2, None, None] * out_5x5
        
        return torch.sigmoid(out)


# ==================== 创新点2: 动态阈值生成器 ====================

class DynamicThresholdGenerator(nn.Module):
    """
    动态阈值生成器(DTG)
    根据特征统计量预测逐像素的软阈值
    """
    def __init__(self, channels):
        super().__init__()
        
        # 全局统计
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        # 阈值预测网络
        self.threshold_net = nn.Sequential(
            # 空间特征提取
            nn.Conv2d(channels, channels, 3, 1, 1, groups=channels),
            nn.Conv2d(channels, channels // 2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 2, channels // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 4, channels, 1),
            nn.Softplus()  # 确保阈值为正
        )
        
        # 全局调制
        self.global_modulation = nn.Sequential(
            nn.Linear(channels, channels // 4),
            nn.ReLU(inplace=True),
            nn.Linear(channels // 4, channels),
            nn.Sigmoid()
        )
        
        # 基础阈值（可学习）
        self.base_threshold = nn.Parameter(torch.tensor(0.01))
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        返回: (B, C, H, W) 逐像素阈值
        """
        B, C, H, W = x.shape
        
        # 全局统计
        global_feat = self.global_pool(x).view(B, C)
        global_mod = self.global_modulation(global_feat).view(B, C, 1, 1)
        
        # 空间阈值预测
        spatial_thr = self.threshold_net(x)
        
        # 结合全局和局部
        threshold = self.base_threshold + 0.1 * spatial_thr * global_mod
        
        return threshold


# ==================== 创新点3: 特征细化模块 ====================

class FeatureRefinementModule(nn.Module):
    """
    特征细化模块
    保留高频细节，增强小目标检测
    """
    def __init__(self, channels):
        super().__init__()
        
        # 高频提取（类似Laplacian）
        self.high_freq = nn.Sequential(
            nn.Conv2d(channels, channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, 1, 1),
        )
        
        # 低频提取
        self.low_freq = nn.Sequential(
            nn.AvgPool2d(3, 1, 1),
            nn.Conv2d(channels, channels, 1),
        )
        
        # 自适应融合
        self.fusion = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 1),
        )
        
        # 残差缩放
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        
        # 高频成分
        high = self.high_freq(x) - self.low_freq(x)
        
        # 融合
        concat = torch.cat([x, high], dim=1)
        refined = self.fusion(concat)
        
        return identity + self.gamma * refined


# ==================== 主模块 ====================

class DynamicEnhanced_DIST_BasicBlock(nn.Module):
    """
    动态增强版DIST BasicBlock
    
    保留原始设计：
    - 静态卷积分支
    - 动态卷积分支（增强为多尺度）
    - 双分支融合
    - 对称约束
    
    创新增强：
    - 动态多尺度卷积（3×3 + 5×5）
    - 动态阈值生成器
    - 特征细化模块
    """
    def __init__(self, **kwargs):
        super(DynamicEnhanced_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        input_dim = 11 * 11 * c * c
        
        # ===== 静态分支（保持原设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 【创新点1】动态多尺度卷积分支 =====
        self.dynamic_ms_conv = DynamicMultiScaleConv(input_dim, hidden_dim=256)
        
        # ===== 【创新点2】动态阈值生成器 =====
        self.dynamic_threshold = DynamicThresholdGenerator(64)
        
        # ===== 【创新点3】特征细化模块 =====
        self.feature_refine = FeatureRefinementModule(64)
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        # 保存原始输入用于动态分支
        x_original = x
        
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 静态分支 =====
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # ===== 【创新点1】动态多尺度卷积分支 =====
        x_dynamic = self.dynamic_ms_conv(x_original, x_input)
        # 扩展到64通道
        x_dynamic = x_dynamic.expand(-1, 64, -1, -1)
        
        # ===== 双分支融合 =====
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_dynamic
        
        # ===== 【创新点3】特征细化 =====
        x_refined = self.feature_refine(x_combined)
        
        # ===== 【创新点2】动态软阈值 =====
        threshold = self.dynamic_threshold(x_refined)
        x_thresh = torch.sign(x_refined) * F.relu(torch.abs(x_refined) - threshold)
        
        # ===== 后向变换 =====
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 对称损失 =====
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试代码 ====================

if __name__ == "__main__":
    print("Testing DynamicEnhanced_DIST_BasicBlock...")
    
    batch_size = 16
    c = 3
    
    block = DynamicEnhanced_DIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    
    total_params = sum(p.numel() for p in block.parameters())
    print(f"Total parameters: {total_params:,}")
    
    print("Test passed!")