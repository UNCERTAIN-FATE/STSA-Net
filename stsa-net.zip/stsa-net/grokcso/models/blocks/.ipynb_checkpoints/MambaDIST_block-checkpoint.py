"""
MambaDIST_BasicBlock: 基于DISTANet动态框架的Mamba增强模块（显存优化版）

创新点（可用于论文）：
1. Mamba增强动态阈值生成器(Mamba-DTG)：用选择性状态空间模型替代LSK注意力，
   以O(N)复杂度实现全局感受野的自适应阈值生成
2. 高效双向扫描(EBS)：用并行卷积替代循环扫描，大幅降低显存占用
3. 状态选择性软阈值(SSST)：将Mamba的选择性机制与软阈值收缩结合

保留DISTANet核心设计：
- 双分支动态变换模块（主分支Conv + 辅助分支动态卷积）
- lambda_weight加权融合
- 对称约束损失
- 完全兼容原始DIST_BasicBlock接口

显存优化：
- 用并行卷积替代循环扫描
- 减少中间变量
- 深度可分离卷积
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 高效Mamba组件（显存优化）====================

class EfficientSS2D(nn.Module):
    """
    高效2D选择性扫描
    用4方向深度卷积模拟全局扫描，显存友好
    
    创新点：
    - 4方向卷积实现全局感受野（水平、垂直、两个对角线）
    - 选择性门控机制模拟Mamba的选择性
    - 全局上下文注入
    """
    def __init__(self, d_model):
        super().__init__()
        self.d_model = d_model
        
        # 4方向卷积（水平、垂直、对角线）
        self.conv_h = nn.Conv2d(d_model, d_model, (1, 7), padding=(0, 3), groups=d_model)
        self.conv_v = nn.Conv2d(d_model, d_model, (7, 1), padding=(3, 0), groups=d_model)
        self.conv_d1 = nn.Conv2d(d_model, d_model, 3, padding=1, groups=d_model)
        self.conv_d2 = nn.Conv2d(d_model, d_model, 5, padding=2, groups=d_model)
        
        # 全局上下文
        self.global_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(d_model, d_model // 4, 1),
            nn.GELU(),
            nn.Conv2d(d_model // 4, d_model, 1),
            nn.Sigmoid()
        )
        
        # 融合
        self.fusion = nn.Sequential(
            nn.Conv2d(d_model * 4, d_model, 1),
            nn.BatchNorm2d(d_model),
            nn.GELU()
        )
        
        # 选择性门控
        self.gate_conv = nn.Sequential(
            nn.Conv2d(d_model, d_model, 3, padding=1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        """
        # 4方向特征
        f_h = F.gelu(self.conv_h(x))
        f_v = F.gelu(self.conv_v(x))
        f_d1 = F.gelu(self.conv_d1(x))
        f_d2 = F.gelu(self.conv_d2(x))
        
        # 融合
        f_cat = torch.cat([f_h, f_v, f_d1, f_d2], dim=1)
        f_fused = self.fusion(f_cat)
        
        # 全局注意力加权
        global_weight = self.global_attn(x)
        f_fused = f_fused * global_weight
        
        # 选择性门控
        gate = self.gate_conv(x)
        
        return gate * f_fused + (1 - gate) * x


# ==================== Mamba增强的动态阈值生成器（优化版）====================

class MambaDTG(nn.Module):
    """
    Mamba-enhanced Dynamic Threshold Generator (显存优化版)
    
    创新点：
    1. 双尺度特征提取捕获不同粒度信息
    2. 高效SS2D实现全局感受野
    3. 通道注意力增强重要特征
    """
    def __init__(self, channels=64):
        super().__init__()
        
        # 双尺度特征提取（深度可分离卷积节省显存）
        self.conv1 = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.BatchNorm2d(channels),
            nn.GELU()
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(channels, channels, 5, padding=2, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.BatchNorm2d(channels),
            nn.GELU()
        )
        
        # 高效Mamba全局建模
        self.ss2d = EfficientSS2D(channels * 2)
        
        # 通道注意力
        self.channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels * 2, channels // 4, 1),
            nn.GELU(),
            nn.Conv2d(channels // 4, channels * 2, 1),
            nn.Sigmoid()
        )
        
        # 阈值生成
        self.threshold_conv = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.GELU(),
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.Softplus()
        )
        
    def forward(self, x):
        """
        x: (B, C, H, W)
        返回: 自适应阈值 (B, C, H, W)
        """
        # 多尺度特征
        f1 = self.conv1(x)
        f2 = self.conv2(x)
        f_cat = torch.cat([f1, f2], dim=1)
        
        # Mamba全局建模
        f_global = self.ss2d(f_cat)
        
        # 通道注意力加权
        f_attn = f_global * self.channel_attn(f_global)
        
        # 生成阈值
        threshold = self.threshold_conv(f_attn)
        
        return threshold * 0.1


class StateSelectiveSoftThreshold(nn.Module):
    """
    State-Selective Soft Threshold
    状态选择性软阈值
    """
    def __init__(self, channels=64):
        super().__init__()
        self.mamba_dtg = MambaDTG(channels)
        
    def forward(self, x):
        threshold = self.mamba_dtg(x)
        return torch.mul(torch.sign(x), F.relu(torch.abs(x) - threshold))


# ==================== 主模块：MambaDIST_BasicBlock ====================

class MambaDIST_BasicBlock(nn.Module):
    """
    MambaDIST BasicBlock - 基于DISTANet动态框架的Mamba增强模块（显存优化版）
    
    保留DISTANet核心设计：
    1. 双分支动态变换（主分支Conv + 辅助分支动态卷积）
    2. lambda_weight加权融合
    3. 对称约束
    
    创新改进：
    1. 用Mamba风格的全局建模增强DTG
    2. 4方向高效扫描实现全局感受野
    3. 选择性门控机制
    """
    def __init__(self, **kwargs):
        super(MambaDIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # ===== 前向变换（保持原始设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 动态卷积分支（保持原始设计）=====
        self.w1 = nn.Linear(11 * 11 * c * c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # ===== 创新：Mamba增强的动态阈值生成器 =====
        self.mamba_soft_threshold = StateSelectiveSoftThreshold(channels=64)
        
        # ===== 后向变换（保持原始设计）=====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        minor = x
        
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 前向变换（主分支）=====
        x = F.conv2d(x_input, self.conv1_forward, padding=1)
        x = F.relu(x)
        x_forward = F.conv2d(x, self.conv2_forward, padding=1)
        
        # ===== 动态卷积分支（辅助分支）=====
        minor = self.w1(minor)
        weights = self.w2(minor)
        weights = weights.reshape(-1, 1, 3, 3)
        x_dynamic = F.conv2d(
            input=x_input, weight=weights, 
            stride=1, padding=1, groups=1
        )
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # ===== 双分支融合 =====
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_dynamic
        
        # ===== 创新：Mamba增强的软阈值 =====
        x = self.mamba_soft_threshold(x_combined)
        
        # ===== 后向变换 =====
        x = F.conv2d(x, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_backward = F.conv2d(x, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 计算对称损失 =====
        x = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_est = F.conv2d(x, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试代码 ====================

if __name__ == "__main__":
    print("Testing MambaDIST_BasicBlock (Memory Optimized)...")
    
    batch_size = 2
    c = 3
    
    block = MambaDIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    
    total_params = sum(p.numel() for p in block.parameters())
    print(f"Total parameters: {total_params:,}")
    
    print("Test passed!")