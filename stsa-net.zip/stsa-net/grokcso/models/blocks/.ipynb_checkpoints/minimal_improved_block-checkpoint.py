# paste into grokcso/models/blocks/minimal_improved_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class ImprovedLSKAttention(nn.Module):
    """改进的LSK - 只加通道注意力，保持稳定"""
    def __init__(self, dim=64):
        super().__init__()
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        self.conv_spatial = nn.Conv2d(dim, dim, 7, stride=1, padding=9, groups=dim, dilation=3)
        self.conv1 = nn.Conv2d(dim, dim//2, 1)
        self.conv2 = nn.Conv2d(dim, dim//2, 1)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim//2, dim, 1)
        
        # 只添加轻量级通道注意力
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim//8, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim//8, dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x):   
        attn1 = self.conv0(x)
        attn2 = self.conv_spatial(attn1)
        attn1 = self.conv1(attn1)
        attn2 = self.conv2(attn2)
        
        attn = torch.cat([attn1, attn2], dim=1)
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn = attn1 * sig[:,0,:,:].unsqueeze(1) + attn2 * sig[:,1,:,:].unsqueeze(1)
        attn = self.conv(attn)
        
        # 通道注意力加权
        ca = self.ca(x)
        attn = attn * ca
        
        return attn

class ResidualEnhance(nn.Module):
    """轻量级残差增强 - 只加一个残差块"""
    def __init__(self, channels=64):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)
        
    def forward(self, x):
        residual = x
        out = self.relu(self.conv1(x))
        out = self.conv2(out)
        out = out * 0.2 + residual  # 小权重残差
        return self.relu(out)

class MinimalImprovedBlock(nn.Module):
    """极简改进版 - 只改最关键的3个点"""
    def __init__(self, c=1, lambda_weight=0.5, **kwargs):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        
        # 基础卷积（完全保留）
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        # 动态卷积（完全保留）
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 改进点1: 增强的LSK注意力
        self.att = ImprovedLSKAttention(dim=64)
        
        # 改进点2: 轻量级残差增强（只用在forward特征上）
        self.residual_enhance = ResidualEnhance(channels=64)
        
        # 改进点3: 可学习的融合权重（替代固定的lambda_weight）
        self.fusion_weight = nn.Parameter(torch.tensor([lambda_weight], dtype=torch.float32))
        
    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]
        minor = x.clone()
        
        # 梯度步（完全保留）
        x_vec = x.view(B, N, 1)
        if PhiTPhi.dim() == 2:
            PhiTPhi = PhiTPhi.unsqueeze(0).expand(B, -1, -1)
        if PhiTb.dim() == 1:
            PhiTb = PhiTb.unsqueeze(0).expand(B, -1)
        
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)
        
        H = 11 * self.c
        x_input = x.view(B, 1, H, H)
        
        # 前向卷积（完全保留）
        h = F.conv2d(x_input, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)
        
        # 改进点2: 残差增强（只用在forward上，保持稳定）
        x_forward_enhanced = self.residual_enhance(x_forward)
        
        # 动态卷积分支（完全保留）
        minor_feat = self.w1(minor)
        weights = self.w2(minor_feat)
        weights = weights.reshape(B, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 改进点3: 可学习的融合权重
        fusion_w = torch.sigmoid(self.fusion_weight)  # 限制在(0,1)
        x_fused = fusion_w * x_forward_enhanced + (1 - fusion_w) * x_dynamic
        
        # 改进点1: 增强的LSK注意力（应用在融合后的特征上）
        threshold = self.att(x_fused)
        x_thresholded = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # 后向卷积（完全保留）
        h2 = F.conv2d(x_thresholded, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)
        
        # 对称损失（完全保留）
        h_est = F.conv2d(x_forward_enhanced, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]