"""
MinimalMambaDIST_BasicBlock: 最小化修改的Mamba增强模块
仅将动态卷积替换为单个RSSB
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from einops import rearrange

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class SimpleRSSB(nn.Module):
    """简化版RSSB"""
    def __init__(self, dim):
        super().__init__()
        
        # 局部卷积
        self.conv1 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        
        # 全局建模（用大核卷积近似）
        self.global_conv = nn.Conv2d(dim, dim, 7, 1, 3, groups=dim)
        
        # 通道混合
        self.channel_mix = nn.Sequential(
            nn.Conv2d(dim, dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(dim * 2, dim, 1)
        )
        
        # 通道注意力
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        
        # 局部
        x = self.conv1(x)
        x = F.gelu(x)
        
        # 全局
        x = x + self.global_conv(x)
        
        # 通道混合
        x = self.channel_mix(x)
        
        # 局部后处理
        x = self.conv2(x)
        
        # 通道注意力
        x = x * self.ca(x)
        
        return identity + self.gamma * x


class MinimalMambaDIST_BasicBlock(nn.Module):
    """最小化修改的Mamba增强模块"""
    def __init__(self, **kwargs):
        super(MinimalMambaDIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 静态分支（完全保持原设计）
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # Mamba分支（替代动态卷积）
        self.mamba_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.mamba_block = SimpleRSSB(64)
        
        # 软阈值（保持原设计）
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        # 后向变换
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        # ISTA步骤
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # Mamba分支
        x_mamba = self.mamba_proj(x_input)
        x_mamba = self.mamba_block(x_mamba)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_mamba
        
        # 软阈值
        x_thresh = torch.mul(
            torch.sign(x_combined), 
            F.relu(torch.abs(x_combined) - self.soft_thr)
        )
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]