"""
消融实验配置

============================================================
消融实验设计：
============================================================
| 配置 | RSSB | STSC | AST | Block类名 | 说明 |
|------|------|------|-----|-----------|------|
| Baseline | ❌ | ❌ | ❌ | DIST_BasicBlock (原始) | 原始DISTA-Net |
| +RSSB | ✅ | ❌ | ❌ | Ablation_RSSB_Only_Block | 只加RSSB |
| +RSSB+STSC | ✅ | ✅ | ❌ | Ablation_RSSB_STSC_Block | RSSB + 小目标敏感卷积 |
| +RSSB+AST | ✅ | ❌ | ✅ | Ablation_RSSB_AST_Block | RSSB + 自适应稀疏阈值 |
| Full (Ours) | ✅ | ✅ | ✅ | CSIST_RSSB_DIST_BasicBlock | 完整模型 |

============================================================
使用方法：
============================================================

步骤1: 复制此文件到blocks目录
    cp ablation_blocks.py /path/to/grokcso/blocks/

步骤2: 创建消融实验配置文件
    
    例如创建 configs/ablation_rssb_only.py:
    
    ```python
    _base_ = ['./your_base_config.py']
    
    # 导入消融Block
    # 在模型定义中使用 Ablation_RSSB_Only_Block
    ```

步骤3: 修改你的模型构建代码
    
    在构建模型的地方，导入并使用对应的Block:
    
    ```python
    from blocks.ablation_blocks import Ablation_RSSB_Only_Block
    
    # 在模型初始化时使用
    block = Ablation_RSSB_Only_Block(c=3, lambda_weight=0.7)
    ```

步骤4: 训练
    python train.py configs/ablation_rssb_only.py --work-dir work_dirs/ablation_rssb_only

============================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 公共模块 ====================

class SimpleRSSB(nn.Module):
    """RSSB模块"""
    def __init__(self, dim):
        super().__init__()
        self.conv1 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.global_conv = nn.Conv2d(dim, dim, 7, 1, 3, groups=dim)
        self.channel_mix = nn.Sequential(
            nn.Conv2d(dim, dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(dim * 2, dim, 1)
        )
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        x = self.conv1(x)
        x = F.gelu(x)
        x = x + self.global_conv(x)
        x = self.channel_mix(x)
        x = self.conv2(x)
        x = x * self.ca(x)
        return identity + self.gamma * x


class SmallTargetSensitiveConv(nn.Module):
    """STSC模块"""
    def __init__(self, dim):
        super().__init__()
        self.conv1x1 = nn.Conv2d(dim, dim, 1, 1, 0)
        self.conv3x3 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.center_attention = nn.Sequential(
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.enhance = nn.Sequential(
            nn.Conv2d(dim, dim, 1),
            nn.GELU(),
            nn.Conv2d(dim, dim, 1)
        )
        
    def forward(self, x):
        f1 = self.conv1x1(x)
        f3 = self.conv3x3(x)
        alpha = torch.sigmoid(self.alpha)
        f_multi = alpha * f1 + (1 - alpha) * f3
        attn = self.center_attention(f_multi)
        f_weighted = f_multi * attn
        out = self.enhance(f_weighted)
        return x + out


class AdaptiveSparseThreshold(nn.Module):
    """AST模块"""
    def __init__(self, dim, base_threshold=0.01):
        super().__init__()
        self.base_threshold = nn.Parameter(torch.tensor(base_threshold))
        self.stat_encoder = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(dim, dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(dim // 4, 1),
            nn.Softplus()
        )
        self.spatial_mod = nn.Sequential(
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, 1, 1),
            nn.Sigmoid()
        )
        self.tau_min = 1e-4
        self.tau_max = 0.05
        
    def forward(self, x):
        B, C, H, W = x.shape
        stat_mod = self.stat_encoder(x)
        spatial_mod = self.spatial_mod(x)
        threshold = self.base_threshold * (1 + 0.1 * stat_mod.view(B, 1, 1, 1)) * (0.5 + spatial_mod)
        threshold = torch.clamp(threshold, self.tau_min, self.tau_max)
        x_thresh = torch.sign(x) * F.relu(torch.abs(x) - threshold)
        return x_thresh


# ==================== 消融配置1: 只有RSSB（方案三）====================

class Ablation_RSSB_Only_Block(nn.Module):
    """
    消融配置: RSSB only
    对应方案三的结果
    """
    def __init__(self, **kwargs):
        super().__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # 固定软阈值（原始设计）
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # 固定软阈值
        x_thresh = torch.mul(torch.sign(x_combined), F.relu(torch.abs(x_combined) - self.soft_thr))
        
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 消融配置2: RSSB + STSC ====================

class Ablation_RSSB_STSC_Block(nn.Module):
    """
    消融配置: RSSB + STSC (无AST)
    验证STSC的贡献
    """
    def __init__(self, **kwargs):
        super().__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # STSC模块
        self.stsc = SmallTargetSensitiveConv(64)
        
        # 固定软阈值
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))
        
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # STSC
        x_stsc = self.stsc(x_combined)
        
        # 固定软阈值
        x_thresh = torch.mul(torch.sign(x_stsc), F.relu(torch.abs(x_stsc) - self.soft_thr))
        
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        x_sym = F.conv2d(x_stsc, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 消融配置3: RSSB + AST ====================

class Ablation_RSSB_AST_Block(nn.Module):
    """
    消融配置: RSSB + AST (无STSC)
    验证AST的贡献
    """
    def __init__(self, **kwargs):
        super().__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # AST模块
        self.ast = AdaptiveSparseThreshold(64, base_threshold=0.01)
        
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # AST (自适应阈值)
        x_thresh = self.ast(x_combined)
        
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 完整模型: RSSB + STSC + AST ====================

class CSIST_RSSB_DIST_BasicBlock(nn.Module):
    """
    完整模型: RSSB + STSC + AST
    这是最终版本，mAP=46.83
    """
    def __init__(self, **kwargs):
        super().__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # STSC模块
        self.stsc = SmallTargetSensitiveConv(64)
        
        # AST模块
        self.ast = AdaptiveSparseThreshold(64, base_threshold=0.01)
        
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = nn.Parameter(torch.Tensor([lambda_weight]))
        
    def forward(self, x, PhiTPhi, PhiTb):
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 静态分支
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # RSSB分支
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        # 融合
        x_combined = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_rssb
        
        # STSC
        x_stsc = self.stsc(x_combined)
        
        # AST (自适应阈值)
        x_thresh = self.ast(x_stsc)
        
        # 后向变换
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x_sym = F.conv2d(x_stsc, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试 ====================

if __name__ == "__main__":
    print("=" * 60)
    print("消融实验配置测试")
    print("=" * 60)
    
    batch_size = 4
    c = 3
    
    configs = [
        ("RSSB only", Ablation_RSSB_Only_Block),
        ("RSSB + STSC", Ablation_RSSB_STSC_Block),
        ("RSSB + AST", Ablation_RSSB_AST_Block),
        ("Full (RSSB + STSC + AST)", CSIST_RSSB_DIST_BasicBlock),
    ]
    
    print("\n参数量统计：")
    print("-" * 40)
    
    for name, BlockClass in configs:
        block = BlockClass(c=c, lambda_weight=0.7)
        total_params = sum(p.numel() for p in block.parameters())
        print(f"  {name}: {total_params:,} params ({total_params/1e3:.1f}K)")
    
    print("\n" + "=" * 60)
    print("所有配置测试成功！")
    print("=" * 60)
    
    print("""
下一步：
1. 复制此文件到 grokcso/blocks/ 目录
2. 为每个配置创建训练配置文件
3. 运行训练并记录结果

训练命令示例：
    python train.py configs/ablation_rssb_only.py --work-dir work_dirs/ablation_rssb_only
    python train.py configs/ablation_rssb_stsc.py --work-dir work_dirs/ablation_rssb_stsc
    python train.py configs/ablation_rssb_ast.py --work-dir work_dirs/ablation_rssb_ast
""")