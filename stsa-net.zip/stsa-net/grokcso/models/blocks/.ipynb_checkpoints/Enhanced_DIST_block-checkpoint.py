"""
Enhanced_DIST_BasicBlock: 增强型DIST模块
创新点（可用于论文）:
1. 通道-空间双重注意力增强的动态阈值生成
2. 残差连接增强梯度流动
3. 特征重标定机制

特点：参数量增加很少，训练速度几乎不变，但有明确创新点
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class ChannelAttention(nn.Module):
    """轻量级通道注意力"""
    def __init__(self, channels, reduction=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // reduction, channels, 1, bias=False)
        )
        
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        return torch.sigmoid(avg_out + max_out)


class SpatialAttention(nn.Module):
    """轻量级空间注意力"""
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size//2, bias=False)
        
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x_cat = torch.cat([avg_out, max_out], dim=1)
        return torch.sigmoid(self.conv(x_cat))


class EnhancedDTG(nn.Module):
    """增强型动态阈值生成器 - 核心创新"""
    def __init__(self, channels):
        super(EnhancedDTG, self).__init__()
        # 双分支特征提取
        self.local_conv = nn.Conv2d(channels, channels, 3, padding=1, groups=channels)
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        # 通道+空间双重注意力
        self.ca = ChannelAttention(channels, reduction=8)
        self.sa = SpatialAttention(kernel_size=3)  # 小kernel加速
        
        # 阈值生成
        self.threshold_conv = nn.Sequential(
            nn.Conv2d(channels, channels, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # 局部特征
        local_feat = self.local_conv(x)
        
        # 全局特征
        B, C, H, W = x.shape
        global_feat = self.global_pool(x).expand(-1, -1, H, W)
        
        # 特征融合
        feat = local_feat + global_feat
        
        # 双重注意力增强
        feat = feat * self.ca(feat)
        feat = feat * self.sa(feat)
        
        # 生成阈值
        threshold = self.threshold_conv(feat)
        return threshold * 0.1  # 缩放确保合理范围


class Enhanced_DIST_BasicBlock(nn.Module):
    """
    增强型DIST模块
    与原始DIST_BasicBlock相比:
    - 用EnhancedDTG替代LSKmodule生成动态阈值
    - 添加残差连接增强梯度流动
    - 参数量几乎不变，但有明确创新点
    """
    def __init__(self, **kwargs):
        super(Enhanced_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 前向变换 (保持原始结构)
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # 动态卷积分支 (保持原始结构)
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 核心创新：增强型动态阈值生成器
        self.enhanced_dtg = EnhancedDTG(64)
        
        # 后向变换 (保持原始结构)
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        minor = x
        
        # ISTA迭代步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 前向变换
        x = F.conv2d(x_input, self.conv1_forward, padding=1)
        x = F.relu(x)
        x_forward = F.conv2d(x, self.conv2_forward, padding=1)
        
        # 动态卷积分支
        minor = self.w1(minor)
        weights = self.w2(minor)
        weights = weights.reshape(-1, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 双分支融合
        x_fused = self.lambda_weight * x_forward + (1 - self.lambda_weight) * x_dynamic
        
        # 核心创新：使用增强型DTG生成动态阈值
        threshold = self.enhanced_dtg(x_fused)
        
        # 软阈值操作 + 残差连接
        x_soft = torch.mul(torch.sign(x_fused), 
                          F.relu(torch.abs(x_fused) - threshold))
        x = x_soft + x_fused * 0.1  # 残差连接
        
        # 后向变换
        x = F.conv2d(x, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_backward = F.conv2d(x, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 对称损失
        x = F.conv2d(x_fused, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_est = F.conv2d(x, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


if __name__ == "__main__":
    # 测试
    batch_size = 2
    c = 3
    
    block = Enhanced_DIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11*11*c*c).to(device)
    PhiTPhi = torch.randn(11*11*c*c, 11*11*c*c).to(device)
    PhiTb = torch.randn(batch_size, 11*11*c*c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    print(f"Input: {x.shape} -> Output: {output.shape}")
    print("Test passed!")