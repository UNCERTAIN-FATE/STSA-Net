# paste into grokcso/models/blocks/dynamic_residual_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class DenseResidualBlock(nn.Module):
    """密集残差块 - 增强特征复用"""
    def __init__(self, channels=64, growth_rate=16):
        super().__init__()
        self.growth_rate = growth_rate
        
        self.conv1 = nn.Sequential(
            nn.Conv2d(channels, growth_rate, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(channels + growth_rate, growth_rate, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(channels + 2*growth_rate, growth_rate, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(channels + 3*growth_rate, growth_rate, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        
        # 特征融合
        self.fusion = nn.Sequential(
            nn.Conv2d(channels + 4*growth_rate, channels, 1),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(torch.cat([x, x1], dim=1))
        x3 = self.conv3(torch.cat([x, x1, x2], dim=1))
        x4 = self.conv4(torch.cat([x, x1, x2, x3], dim=1))
        
        out = self.fusion(torch.cat([x, x1, x2, x3, x4], dim=1))
        return out + x

class DynamicKernelGenerator(nn.Module):
    """动态卷积核生成器 - 根据输入特征生成卷积核"""
    def __init__(self, in_features, out_channels=64, kernel_size=3):
        super().__init__()
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        
        # 使用更深的网络生成核
        self.generator = nn.Sequential(
            nn.Linear(in_features, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, out_channels * kernel_size * kernel_size)
        )
        
        # 核标准化
        self.norm = nn.LayerNorm(out_channels * kernel_size * kernel_size)
        
    def forward(self, features):
        """
        features: [B, F] 全局特征
        returns: [B, out_channels, kernel_size, kernel_size] 动态核
        """
        B = features.shape[0]
        kernels = self.generator(features)
        kernels = self.norm(kernels)
        kernels = kernels.view(B, self.out_channels, self.kernel_size, self.kernel_size)
        return kernels

class ChannelSpatialAttention(nn.Module):
    """通道-空间联合注意力"""
    def __init__(self, channels=64, reduction=8):
        super().__init__()
        
        # 通道注意力
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels//reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//reduction, channels, 1, bias=False)
        )
        
        # 空间注意力
        self.spatial_conv = nn.Sequential(
            nn.Conv2d(2, 1, 7, padding=3, bias=False),
            nn.Sigmoid()
        )
        
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        # 通道注意力
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        channel_att = self.sigmoid(avg_out + max_out)
        x = x * channel_att
        
        # 空间注意力
        avg_spatial = torch.mean(x, dim=1, keepdim=True)
        max_spatial, _ = torch.max(x, dim=1, keepdim=True)
        spatial = torch.cat([avg_spatial, max_spatial], dim=1)
        spatial_att = self.spatial_conv(spatial)
        x = x * spatial_att
        
        return x

class ContextAggregation(nn.Module):
    """上下文聚合模块 - 聚合全局和局部信息"""
    def __init__(self, channels=64):
        super().__init__()
        
        # 全局分支
        self.global_branch = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels//2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//2, channels, 1),
            nn.Sigmoid()
        )
        
        # 局部分支 - 多个感受野
        self.local_branch1 = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.ReLU(inplace=True)
        )
        self.local_branch2 = nn.Sequential(
            nn.Conv2d(channels, channels, 5, padding=2, groups=channels),
            nn.Conv2d(channels, channels, 1),
            nn.ReLU(inplace=True)
        )
        
        # 融合
        self.fusion = nn.Sequential(
            nn.Conv2d(channels*2, channels, 1),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, x):
        B, C, H, W = x.shape
        
        # 全局加权
        global_weight = self.global_branch(x)
        x_global = x * global_weight
        
        # 局部特征
        local1 = self.local_branch1(x)
        local2 = self.local_branch2(x)
        x_local = local1 + local2
        
        # 融合
        out = self.fusion(torch.cat([x_global, x_local], dim=1))
        return out + x

class DynamicResidualBlock(nn.Module):
    """动态残差密集模块 - 整合多种增强策略"""
    def __init__(self, c=1, lambda_weight=0.5, **kwargs):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        
        # 基础卷积
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        # 原始动态卷积
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 密集残差块
        self.dense_block1 = DenseResidualBlock(channels=64, growth_rate=16)
        self.dense_block2 = DenseResidualBlock(channels=64, growth_rate=16)
        
        # 通道-空间注意力
        self.cs_attention = ChannelSpatialAttention(channels=64, reduction=8)
        
        # 上下文聚合
        self.context_agg = ContextAggregation(channels=64)
        
        # 增强的动态核生成器
        self.kernel_gen = DynamicKernelGenerator(
            in_features=11*11*c*c, 
            out_channels=64, 
            kernel_size=3
        )
        
        # 动态核应用层
        self.dynamic_conv = nn.Conv2d(64, 64, 1)
        
        # 高级阈值生成
        self.threshold_net = nn.Sequential(
            nn.Conv2d(64, 32, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, 1),
            nn.Sigmoid()
        )
        
        # 残差缩放因子（可学习）
        self.residual_scale = nn.Parameter(torch.ones(1))
        
    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]
        minor = x.clone()
        
        # 梯度步
        x_vec = x.view(B, N, 1)
        if PhiTPhi.dim() == 2:
            PhiTPhi = PhiTPhi.unsqueeze(0).expand(B, -1, -1)
        if PhiTb.dim() == 1:
            PhiTb = PhiTb.unsqueeze(0).expand(B, -1)
        
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)
        
        H = 11 * self.c
        x_input = x.view(B, 1, H, H)
        
        # 前向卷积
        h = F.conv2d(x_input, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)
        
        # 密集残差增强
        x_dense1 = self.dense_block1(x_forward)
        x_dense2 = self.dense_block2(x_dense1)
        
        # 通道-空间注意力
        x_att = self.cs_attention(x_dense2)
        
        # 上下文聚合
        x_context = self.context_agg(x_att)
        
        # 生成动态卷积核
        dynamic_kernels = self.kernel_gen(minor)  # [B, 64, 3, 3]
        
        # 应用动态卷积（分组卷积）
        x_dynamic_enhanced = []
        for b in range(B):
            kernel_b = dynamic_kernels[b:b+1]  # [1, 64, 3, 3]
            # 对每个通道应用独立的动态核
            result = F.conv2d(x_context[b:b+1], kernel_b, padding=1, groups=1)
            x_dynamic_enhanced.append(result)
        x_dynamic_enhanced = torch.cat(x_dynamic_enhanced, dim=0)
        x_dynamic_enhanced = self.dynamic_conv(x_dynamic_enhanced)
        
        # 特征融合
        x_combined = x_forward + self.residual_scale * (x_context + x_dynamic_enhanced)
        
        # 原始动态卷积分支
        minor_feat = self.w1(minor)
        weights = self.w2(minor_feat)
        weights = weights.reshape(B, 1, 3, 3)
        x_minor_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_minor_dynamic = torch.sigmoid(x_minor_dynamic)
        
        # 双路融合
        x_fused = self.lambda_weight * x_combined + (1 - self.lambda_weight) * x_minor_dynamic
        
        # 高级自适应阈值
        threshold = self.threshold_net(x_fused) * 0.08 + 0.0005
        x_thresholded = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # 后向卷积
        h2 = F.conv2d(x_thresholded, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)
        
        # 对称损失
        h_est = F.conv2d(x_combined, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]