# -*- coding: utf-8 -*-
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import timm

from mamba_ssm import Mamba
from ..tricks.attention_block import LSKmodule

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


################################################################################
# Mamba + DINO → multi-head gamma 生成器（弱调制，不破坏阈值结构）
################################################################################

class DinoMambaGamma(nn.Module):
    def __init__(self, dino_dim=768, hidden_dim=256, heads=4):
        super().__init__()
        self.heads = heads

        # reduce channel
        self.pre = nn.Sequential(
            nn.Conv2d(dino_dim, hidden_dim, 1),
            nn.ReLU(inplace=True)
        )

        # Mamba SSM block
        self.mamba = Mamba(
            d_model=hidden_dim,
            d_state=16,
            d_conv=3
        )

        # out projection
        self.post = nn.Sequential(
            nn.Conv2d(hidden_dim, heads, 1),
            nn.Tanh()       # γ ∈ [-1,1]
        )

    def forward(self, x):
        """
        x: (B, 768, H, W) DINO spatial feature
        """
        B, C, H, W = x.shape

        h = self.pre(x)   # (B, 256, H, W)
        seq = h.flatten(2).transpose(1, 2)        # (B, HW, 256)

        seq_out = self.mamba(seq)                # Mamba core
        out = seq_out.transpose(1, 2).reshape(B, -1, H, W)

        gamma_heads = self.post(out)             # (B, heads, H, W)
        gamma = gamma_heads.sum(dim=1, keepdim=True)  # (B,1,H,W)

        return gamma


################################################################################
# 完整 DISTA Block（DINO + Mamba）版本
################################################################################

class DISTA_MambaBlock(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()

        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']

        # trainable ISTA step-size
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        self.c = c

        ###############################################################################
        # 载入 DINOv2 ViT-B/14
        ###############################################################################
        weight_path = "/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth"

        self.dino = timm.create_model(
            'vit_base_patch14_dinov2.lvd142m',
            pretrained=False,
            num_classes=0,
            global_pool='',
        )

        state_dict = torch.load(weight_path, map_location='cpu')
        self.dino.load_state_dict(state_dict, strict=False)

        self.dino.eval()
        for p in self.dino.parameters():
            p.requires_grad = False

        ###############################################################################
        # CNN 去噪结构（原 DISTA）
        ###############################################################################
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))

        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))

        # CNN 阈值模块（LSKmodule 原始版本）
        self.theta_local = LSKmodule(64)

        # DINO + Mamba 阈值调制模块
        self.gamma_mod = DinoMambaGamma(dino_dim=768, hidden_dim=256, heads=4)

    ###############################################################################
    # DINO 手动 forward（获得空间特征）
    ###############################################################################
    def run_dino(self, x_3ch):
        """
        x_3ch: (B,3,H,W) 输入到 ViT 之前的 3 通道图像
        """
        with torch.no_grad():
            # patch embedding
            patch_proj = self.dino.patch_embed.proj(x_3ch)   # (B,768,H/14,W/14)
            B, D, Hp, Wp = patch_proj.shape

            tokens = patch_proj.flatten(2).transpose(1, 2)   # (B, L, D)
            cls_tok = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls_tok, tokens), dim=1)   # (B, L+1, D)

            # interpolate pos embed
            pos = self.dino.pos_embed
            orig_N = pos.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))

            pos_spatial = pos[:, 1:, :].transpose(1, 2).reshape(1, D, orig_H, orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp, Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1, D, Hp*Wp).transpose(1, 2)

            pos_all = torch.cat([pos[:, 0:1, :], pos_up], dim=1)

            x_tokens = x_tokens + pos_all.to(x_tokens.device)
            x_tokens = self.dino.pos_drop(x_tokens)

            # transformer blocks
            xt = x_tokens
            for blk in self.dino.blocks:
                xt = blk(xt)
            xt = self.dino.norm(xt)

        # remove CLS token
        spatial_tokens = xt[:, 1:, :]                   # (B,L,D)
        spatial = spatial_tokens.transpose(1, 2).reshape(B, D, Hp, Wp)

        return spatial

    ###############################################################################
    # forward
    ###############################################################################

    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]

        ########################################
        # 1. ISTA 梯度步：z = x - λ Aᵀ(Ax - b)
        ########################################
        x_vec = x.view(B, N, 1)
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)

        ########################################
        # 2. reshape
        ########################################
        x_1ch = x.view(B, 1, 11 * self.c, 11 * self.c)
        x_3ch = x_1ch.repeat(1, 3, 1, 1)

        ########################################
        # 3. forward CNN（原 DISTA 前半）
        ########################################
        h = F.conv2d(x_1ch, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)   # (B,64,H,W)

        ########################################
        # 4. CNN 阈值（局部阈值 θ_local）
        ########################################
        theta_local = self.theta_local(x_forward)

        ########################################
        # 5. DINO + Mamba 阈值调制 γ
        ########################################
        spatial = self.run_dino(x_3ch)
        spatial_up = F.interpolate(spatial, size=x_forward.shape[2:], mode='bilinear')

        gamma = self.gamma_mod(spatial_up)            # (B,1,H,W)
        theta_final = theta_local * (1 + 0.3 * gamma) # 0.3 = 稳定系数

        ########################################
        # 6. soft-threshold（最终阈值）
        ########################################
        x_thresh = torch.mul(
            torch.sign(x_forward),
            F.relu(torch.abs(x_forward) - theta_final)
        )

        ########################################
        # 7. backward CNN
        ########################################
        h = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        h = F.relu(h)
        x_backward = F.conv2d(h, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)

        ########################################
        # 8. symmetry loss（原损失）
        ########################################
        h = F.conv2d(x_forward, self.conv1_backward, padding=1)
        h = F.relu(h)
        x_est = F.conv2d(h, self.conv2_backward, padding=1)
        symloss = x_est - x_1ch

        return [x_pred, symloss]
