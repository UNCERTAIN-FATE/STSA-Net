import torch
import numpy as np
from mmengine.config import Config
from mmengine.runner import Runner

# ========== 配置 ==========
config_path = '/root/autodl-tmp/grokcso/configs/MyDINOThreshold/dista.py'
checkpoint_path = '/root/autodl-fs/improved/epoch_47.pth'
TTA_TRANSFORMS = ['none', 'hflip', 'vflip', 'rotate90', 'rotate180', 'rotate270']
# ==========================

def apply_transform(x, t):
    if t == 'none': return x
    if t == 'hflip': return torch.flip(x, dims=[-1])
    if t == 'vflip': return torch.flip(x, dims=[-2])
    if t == 'rotate90': return torch.rot90(x, k=1, dims=[-2, -1])
    if t == 'rotate180': return torch.rot90(x, k=2, dims=[-2, -1])
    if t == 'rotate270': return torch.rot90(x, k=3, dims=[-2, -1])
    return x

def reverse_transform(x, t):
    if t == 'none': return x
    if t == 'hflip': return torch.flip(x, dims=[-1])
    if t == 'vflip': return torch.flip(x, dims=[-2])
    if t == 'rotate90': return torch.rot90(x, k=-1, dims=[-2, -1])
    if t == 'rotate180': return torch.rot90(x, k=-2, dims=[-2, -1])
    if t == 'rotate270': return torch.rot90(x, k=-3, dims=[-2, -1])
    return x

class TTAModel:
    def __init__(self, model, transforms):
        self.model = model
        self.transforms = transforms
        self.model.eval()
        
    def __call__(self, batch_x, PhiTPhi, batch_y=None):
        B, N = batch_x.shape
        H = int(np.sqrt(N))
        
        predictions = []
        with torch.no_grad():
            for t in self.transforms:
                x_img = batch_x.view(B, 1, H, H)
                x_t = apply_transform(x_img, t).view(B, -1)
                pred, _ = self.model(x_t, PhiTPhi, batch_y)
                pred_img = pred.view(B, 1, H, H)
                pred_restored = reverse_transform(pred_img, t).view(B, -1)
                predictions.append(pred_restored)
        
        final = torch.stack(predictions).mean(0)
        dummy = torch.zeros(B, 1, H, H).to(batch_x.device)
        return final, dummy
    
    def __getattr__(self, name):
        return getattr(self.model, name)

# 加载并测试
cfg = Config.fromfile(config_path)
cfg.work_dir = 'work_dirs/minimal_improved_tta'

runner = Runner.from_cfg(cfg)
runner.load_checkpoint(checkpoint_path)

print(f"\n{'='*60}")
print(f"TTA Transforms: {TTA_TRANSFORMS}")
print(f"{'='*60}\n")

runner.model = TTAModel(runner.model, TTA_TRANSFORMS)
metrics = runner.test()

print(f"\n{'='*60}")
print("Results:")
for k, v in metrics.items():
    print(f"  {k}: {v:.4f}")
print(f"{'='*60}\n")