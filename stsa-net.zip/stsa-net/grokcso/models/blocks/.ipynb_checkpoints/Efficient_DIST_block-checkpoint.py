"""
Efficient_DIST_BasicBlock: Lightweight Efficient DIST Block  
创新点:
1. 深度可分离卷积 - 减少参数量同时保持性能
2. SE注意力 + CBAM空间注意力组合
3. 特征金字塔注意力 - 多尺度信息聚合
4. 改进的软阈值函数 - 可学习的非线性阈值
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class DepthwiseSeparableConv(nn.Module):
    """深度可分离卷积"""
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1, stride=1):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size, 
                                    stride=stride, padding=padding, groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, 1)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.ReLU(inplace=True)
        
    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        x = self.act(x)
        return x


class SEBlock(nn.Module):
    """Squeeze-and-Excitation块"""
    def __init__(self, channels, reduction=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class SpatialAttention(nn.Module):
    """空间注意力模块"""
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        padding = (kernel_size - 1) // 2
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        combined = torch.cat([avg_out, max_out], dim=1)
        attn = self.conv(combined)
        return x * self.sigmoid(attn)


class CBAM(nn.Module):
    """Convolutional Block Attention Module"""
    def __init__(self, channels, reduction=16, kernel_size=7):
        super(CBAM, self).__init__()
        self.channel_attn = SEBlock(channels, reduction)
        self.spatial_attn = SpatialAttention(kernel_size)
        
    def forward(self, x):
        x = self.channel_attn(x)
        x = self.spatial_attn(x)
        return x


class FeaturePyramidAttention(nn.Module):
    """特征金字塔注意力"""
    def __init__(self, channels):
        super(FeaturePyramidAttention, self).__init__()
        
        # 多尺度卷积
        self.conv1 = nn.Conv2d(channels, channels, 1)
        self.conv3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels)
        self.conv5 = nn.Conv2d(channels, channels, 5, padding=2, groups=channels)
        
        # 全局上下文
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.global_conv = nn.Conv2d(channels, channels, 1)
        
        # 融合
        self.fusion = nn.Sequential(
            nn.Conv2d(channels * 4, channels, 1),
            nn.BatchNorm2d(channels),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        B, C, H, W = x.shape
        
        f1 = self.conv1(x)
        f3 = self.conv3(x)
        f5 = self.conv5(x)
        
        fg = self.global_pool(x)
        fg = self.global_conv(fg)
        fg = F.interpolate(fg, size=(H, W), mode='bilinear', align_corners=False)
        
        fused = torch.cat([f1, f3, f5, fg], dim=1)
        attn = self.fusion(fused)
        
        return x * attn + x


class LearnableSoftThreshold(nn.Module):
    """可学习的软阈值函数"""
    def __init__(self, channels):
        super(LearnableSoftThreshold, self).__init__()
        # 基础阈值
        self.base_threshold = nn.Parameter(torch.Tensor([0.1]))
        
        # 自适应阈值生成
        self.threshold_net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels // 4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 4, channels, 1),
            nn.Softplus()  # 确保正值
        )
        
        # 非线性调制
        self.modulation = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # 自适应阈值
        adaptive_threshold = self.threshold_net(x)
        threshold = self.base_threshold + adaptive_threshold * 0.1
        
        # 非线性调制
        modulation = self.modulation(x)
        
        # 软阈值操作
        sign = torch.sign(x)
        magnitude = torch.abs(x) - threshold
        magnitude = F.relu(magnitude)
        
        # 应用调制
        output = sign * magnitude * (1 + modulation * 0.1)
        
        return output


class EfficientInvertedResidual(nn.Module):
    """高效倒残差块"""
    def __init__(self, channels, expand_ratio=4):
        super(EfficientInvertedResidual, self).__init__()
        hidden_dim = channels * expand_ratio
        
        self.conv = nn.Sequential(
            # 扩展
            nn.Conv2d(channels, hidden_dim, 1),
            nn.BatchNorm2d(hidden_dim),
            nn.ReLU6(inplace=True),
            # 深度卷积
            nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, groups=hidden_dim),
            nn.BatchNorm2d(hidden_dim),
            nn.ReLU6(inplace=True),
            # 压缩
            nn.Conv2d(hidden_dim, channels, 1),
            nn.BatchNorm2d(channels)
        )
        
    def forward(self, x):
        return x + self.conv(x)


class Efficient_DIST_BasicBlock(nn.Module):
    """
    Lightweight Efficient DIST BasicBlock
    """
    def __init__(self, **kwargs):
        super(Efficient_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs['lambda_weight']
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # 前向变换 - 深度可分离卷积
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.ds_conv = DepthwiseSeparableConv(64, 64)
        
        # CBAM注意力
        self.cbam = CBAM(64, reduction=8)
        
        # 特征金字塔注意力
        self.fpa = FeaturePyramidAttention(64)
        
        # 高效倒残差块
        self.efficient_block = EfficientInvertedResidual(64, expand_ratio=2)
        
        # 动态卷积分支
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 可学习软阈值
        self.learnable_threshold = LearnableSoftThreshold(64)
        
        # 后向变换
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        minor = x
        
        # ISTA迭代步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # 前向变换
        x = F.conv2d(x_input, self.conv1_forward, padding=1)
        x = F.relu(x)
        x_forward = self.ds_conv(x)
        
        # CBAM注意力
        x_attn = self.cbam(x_forward)
        
        # 特征金字塔注意力
        x_fpa = self.fpa(x_attn)
        
        # 高效倒残差块
        x_efficient = self.efficient_block(x_fpa)
        
        # 动态卷积分支
        minor = self.w1(minor)
        weights = self.w2(minor)
        weights = weights.reshape(-1, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 双分支融合
        x_combined = self.lambda_weight * x_efficient + (1 - self.lambda_weight) * x_dynamic
        
        # 可学习软阈值
        x = self.learnable_threshold(x_combined)
        
        # 后向变换
        x = F.conv2d(x, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_backward = F.conv2d(x, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # 计算对称损失
        x = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x = F.relu(x)
        x_est = F.conv2d(x, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


if __name__ == "__main__":
    # 测试代码
    batch_size = 2
    c = 3
    
    block = Efficient_DIST_BasicBlock(c=c, lambda_weight=0.7)
    block = block.to(device)
    
    x = torch.randn(batch_size, 11*11*c*c).to(device)
    PhiTPhi = torch.randn(11*11*c*c, 11*11*c*c).to(device)
    PhiTb = torch.randn(batch_size, 11*11*c*c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    print("Test passed!")