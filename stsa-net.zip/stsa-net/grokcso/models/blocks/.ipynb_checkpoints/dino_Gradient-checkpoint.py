# paste into grokcso/models/blocks/dino_gradient_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import math
import timm

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class DinoConditionedGradientBlock(nn.Module):
    """
    用 DINO 特征作为 condition 来生成 per-channel scaling factors 或 small dynamic kernels
    for forward convolution (gradient operator). Threshold remains CNN-based (stable).
    """
    def __init__(self, c=1, lambda_weight=0.5,
                 dino_ckpt="/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth",
                 scale_eps=0.05):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        self.scale_eps = scale_eps

        # base forward convs
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))

        # backward convs remain
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))

        # small CNN threshold head (stable)
        self.th_cnn_decoder = nn.Sequential(
            nn.Conv2d(64, 32, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, 1),
            nn.Sigmoid()
        )

        # load DINO (frozen)
        self.dino = timm.create_model('vit_base_patch14_dinov2.lvd142m', pretrained=False, num_classes=0, global_pool='')
        state = torch.load(dino_ckpt, map_location='cpu')
        self.dino.load_state_dict(state, strict=False)
        self.dino.eval()
        for p in self.dino.parameters():
            p.requires_grad = False

        # head to produce channel scaling (for 64 channels)
        # take global-pooled DINO features -> MLP -> 64 dims
        self.scale_mlp = nn.Sequential(
            nn.Linear(768, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 64),
            nn.Tanh()  # in (-1,1)
        )

    def _dino_global(self, x_3ch):
        """Return global pooled dino feature vector [B,768]"""
        B = x_3ch.shape[0]
        # upsample to patch-grid like earlier
        patch_size = self.dino.patch_embed.patch_size[0] if isinstance(self.dino.patch_embed.patch_size, (tuple,list)) else self.dino.patch_embed.patch_size
        min_side = patch_size * 4
        _,_,H,W = x_3ch.shape
        up_h = max(H, min_side); up_w = max(W, min_side)
        x_up = F.interpolate(x_3ch, size=(up_h, up_w), mode='bilinear', align_corners=False)
        with torch.no_grad():
            proj = self.dino.patch_embed.proj(x_up)
            Bp, D, Hp, Wp = proj.shape
            tokens = proj.flatten(2).transpose(1,2)
            cls = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls, tokens), dim=1)
            pos_embed = self.dino.pos_embed
            orig_N = pos_embed.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))
            pos_spatial = pos_embed[:,1:,:].transpose(1,2).reshape(1,D,orig_H,orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp,Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1,D,Hp*Wp).transpose(1,2)
            pos_cls = pos_embed[:,0:1,:]
            pos = torch.cat([pos_cls, pos_up], dim=1).to(x_tokens.device)
            x_tokens = x_tokens + pos
            x_tokens = self.dino.pos_drop(x_tokens)
            xt = x_tokens
            for blk in self.dino.blocks:
                xt = blk(xt)
            xt = self.dino.norm(xt)
        # take cls token as global descriptor
        cls_feat = xt[:,0,:]  # [B, D]
        return cls_feat

    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]; N = x.shape[1]
        x_vec = x.view(B, N, 1)
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)

        H = 11 * self.c
        x_img = x.view(B, 1, H, H)
        x_3ch = x_img.repeat(1,3,1,1)

        # base forward conv
        h = F.conv2d(x_img, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)  # [B,64,H,W]

        # DINO global cond -> channel scales
        dfeat = self._dino_global(x_3ch)  # [B,768]
        scales = self.scale_mlp(dfeat).unsqueeze(-1).unsqueeze(-1).unsqueeze(-1)  # [B,64,1,1]
        # scale in (1-eps, 1+eps)
        scales = 1.0 + self.scale_eps * scales

        # apply per-sample per-channel scaling to x_forward
        x_forward = x_forward * scales  # broadcasting

        # optionally fuse with residual dynamic conv or small hypernet
        # now threshold via cnn
        theta = self.th_cnn_decoder(x_forward) * 0.03
        x_thr = torch.sign(x_forward) * F.relu(torch.abs(x_forward) - theta)

        # backward conv / pred
        h2 = F.conv2d(x_thr, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)

        # symmetry loss as before
        h_est = F.conv2d(x_forward, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_img

        return [x_pred, symloss]
