# paste into grokcso/models/blocks/multiscale_adaptive_block.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class MultiScaleAttention(nn.Module):
    """多尺度注意力模块 - 捕获不同尺度的特征"""
    def __init__(self, channels=64):
        super().__init__()
        # 三个不同尺度的分支
        self.branch1 = nn.Sequential(
            nn.Conv2d(channels, channels//4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//4, channels//4, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.branch2 = nn.Sequential(
            nn.Conv2d(channels, channels//4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//4, channels//4, 3, padding=2, dilation=2),
            nn.ReLU(inplace=True)
        )
        self.branch3 = nn.Sequential(
            nn.Conv2d(channels, channels//4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//4, channels//4, 3, padding=3, dilation=3),
            nn.ReLU(inplace=True)
        )
        self.branch4 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels//4, 1),
            nn.ReLU(inplace=True)
        )
        
        # 融合模块
        self.fusion = nn.Sequential(
            nn.Conv2d(channels, channels, 1),
            nn.ReLU(inplace=True)
        )
        
        # 通道注意力
        self.channel_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels//4, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//4, channels, 1),
            nn.Sigmoid()
        )
        
        # 空间注意力
        self.spatial_att = nn.Sequential(
            nn.Conv2d(2, 1, 7, padding=3),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # 多尺度分支
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)
        b4 = F.interpolate(b4, size=x.shape[2:], mode='bilinear', align_corners=False)
        
        # 特征融合
        feat = torch.cat([b1, b2, b3, b4], dim=1)
        feat = self.fusion(feat)
        
        # 通道注意力
        ca = self.channel_att(feat)
        feat = feat * ca
        
        # 空间注意力
        max_pool = torch.max(feat, dim=1, keepdim=True)[0]
        avg_pool = torch.mean(feat, dim=1, keepdim=True)
        spatial = torch.cat([max_pool, avg_pool], dim=1)
        sa = self.spatial_att(spatial)
        feat = feat * sa
        
        return feat + x  # 残差连接

class AdaptiveThresholdModule(nn.Module):
    """自适应阈值生成模块"""
    def __init__(self, channels=64):
        super().__init__()
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels//4),
            nn.ReLU(inplace=True),
            nn.Linear(channels//4, channels),
            nn.ReLU(inplace=True)
        )
        self.local_conv = nn.Sequential(
            nn.Conv2d(channels, channels//2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels//2, channels, 1)
        )
        self.threshold_conv = nn.Sequential(
            nn.Conv2d(channels, 32, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # 全局特征
        B, C, H, W = x.shape
        global_feat = self.global_pool(x).view(B, C)
        global_feat = self.fc(global_feat).view(B, C, 1, 1)
        global_feat = global_feat.expand(-1, -1, H, W)
        
        # 局部特征
        local_feat = self.local_conv(x)
        
        # 融合
        feat = global_feat + local_feat
        threshold = self.threshold_conv(feat)
        
        # 自适应缩放到合适范围
        threshold = threshold * 0.05 + 0.001
        
        return threshold

class MultiScaleAdaptiveBlock(nn.Module):
    """多尺度自适应增强模块 - 结合多尺度特征和自适应阈值"""
    def __init__(self, c=1, lambda_weight=0.5, **kwargs):
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.tensor([0.5], dtype=torch.float32))
        self.lambda_weight = torch.tensor([lambda_weight], dtype=torch.float32).to(device)
        
        # 基础卷积
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        # 动态卷积权重生成
        self.w1 = nn.Linear(11*11*c*c, 256)
        self.w2 = nn.Linear(256, 9)
        
        # 多尺度注意力
        self.msa = MultiScaleAttention(channels=64)
        
        # 自适应阈值
        self.adaptive_threshold = AdaptiveThresholdModule(channels=64)
        
        # 特征增强
        self.feature_enhance = nn.Sequential(
            nn.Conv2d(64, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, 3, padding=1)
        )
        
    def forward(self, x, PhiTPhi, PhiTb):
        B = x.shape[0]
        N = x.shape[1]
        minor = x
        
        # 梯度步
        x_vec = x.view(B, N, 1)
        if PhiTPhi.dim() == 2:
            PhiTPhi = PhiTPhi.unsqueeze(0).expand(B, -1, -1)
        if PhiTb.dim() == 1:
            PhiTb = PhiTb.unsqueeze(0).expand(B, -1)
        
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)
        
        H = 11 * self.c
        x_input = x.view(B, 1, H, H)
        
        # 前向卷积
        h = F.conv2d(x_input, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)  # [B, 64, H, H]
        
        # 多尺度注意力增强
        x_forward_enhanced = self.msa(x_forward)
        
        # 特征增强
        x_forward_refined = self.feature_enhance(x_forward_enhanced) + x_forward_enhanced
        
        # 动态卷积分支
        minor = self.w1(minor)
        weights = self.w2(minor)
        weights = weights.reshape(B, 1, 3, 3)
        x_dynamic = F.conv2d(input=x_input, weight=weights, stride=1, padding=1, groups=1)
        x_dynamic = torch.sigmoid(x_dynamic)
        
        # 双路融合
        x_fused = self.lambda_weight * x_forward_refined + (1 - self.lambda_weight) * x_dynamic
        
        # 自适应阈值
        threshold = self.adaptive_threshold(x_fused)
        x_thresholded = torch.sign(x_fused) * F.relu(torch.abs(x_fused) - threshold)
        
        # 后向卷积
        h2 = F.conv2d(x_thresholded, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)
        
        # 对称损失
        h_est = F.conv2d(x_forward_refined, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]