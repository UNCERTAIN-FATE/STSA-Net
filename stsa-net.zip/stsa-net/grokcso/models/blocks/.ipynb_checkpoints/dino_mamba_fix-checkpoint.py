# -*- coding: utf-8 -*-
"""
DISTA_MambaBlock_fixed.py
修复说明：
 - Mamba hidden_dim 从 256 -> 128（更稳）
 - gamma 融合改为 residual: theta_final = clamp(theta_local + alpha * gamma)
 - alpha 默认 0.10（可调）
 - gamma 经过 tanh 限幅，防止极端值
 - DINO frozen（同你之前那样）
 - 保持 forward(x, PhiTPhi, PhiTb) 接口
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import timm

# 下面假设仓库中有 mamba_ssm 包。如果没有，请使用你本地 mamba 实现或替代简单 RNN。
from mamba_ssm import Mamba
from ..tricks.attention_block import LSKmodule

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class DinoMambaGammaFixed(nn.Module):
    """
    DINO -> Mamba -> multi-head gamma generator (fixed: smaller hidden dim & safer output)
    Returns gamma in (-1,1), then caller will scale by alpha and fuse residually.
    """
    def __init__(self, dino_dim=768, hidden_dim=128, heads=3):
        super().__init__()
        self.heads = heads
        self.hidden_dim = hidden_dim

        # reduce channel
        self.pre = nn.Sequential(
            nn.Conv2d(dino_dim, hidden_dim, 1),
            nn.ReLU(inplace=True)
        )

        # smaller Mamba block for stability
        self.mamba = Mamba(
            d_model=hidden_dim,
            d_state=16,
            d_conv=3
        )

        # out projection to multi-head gamma maps
        self.post = nn.Sequential(
            nn.Conv2d(hidden_dim, heads, 1),
            nn.Tanh()       # keep in (-1,1)
        )

    def forward(self, x):
        """
        x: (B, 768, H, W) DINO spatial feature
        returns: gamma (B,1,H,W) with values in (-1,1)
        """
        B, C, H, W = x.shape
        h = self.pre(x)  # (B, hidden_dim, H, W)

        # seq: (B, L, hidden_dim)
        seq = h.flatten(2).transpose(1, 2)

        # Mamba expects (B, L, d_model) and returns same shape
        seq_out = self.mamba(seq)
        out = seq_out.transpose(1, 2).reshape(B, -1, H, W)

        gamma_heads = self.post(out)  # (B, heads, H, W)
        # sum heads but keep bounded range
        gamma = gamma_heads.sum(dim=1, keepdim=True)  # (B,1,H,W)
        # ensure gamma is in (-1,1) by extra tanh (redundant if post tanh but safe)
        gamma = torch.tanh(gamma)
        return gamma


class DISTA_MambaBlock_Fixed(nn.Module):
    def __init__(self, c=1, lambda_weight=0.5,
                 dino_ckpt="/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth",
                 alpha=0.10, gamma_heads=3, gamma_hidden=128,
                 tau_min=1e-4, tau_max=0.06):
        """
        alpha: modulation strength (recommended 0.05 ~ 0.15; default 0.10)
        tau_min/tau_max: clamp range for final threshold (safe defaults)
        """
        super().__init__()
        self.c = c
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)

        # load DINOv2 (frozen)
        self.dino = timm.create_model(
            'vit_base_patch14_dinov2.lvd142m',
            pretrained=False,
            num_classes=0,
            global_pool='',
        )
        state_dict = torch.load(dino_ckpt, map_location='cpu')
        self.dino.load_state_dict(state_dict, strict=False)
        self.dino.eval()
        for p in self.dino.parameters():
            p.requires_grad = False

        # original DISTA convs
        self.conv1_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))

        self.conv1_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))

        # original LSK module provides local threshold prior
        self.theta_local = LSKmodule(64)

        # DINO + Mamba modulation (fixed smaller hidden dim)
        self.gamma_mod = DinoMambaGammaFixed(dino_dim=768, hidden_dim=gamma_hidden, heads=gamma_heads)

        # fusion and clamp hyperparams
        self.alpha = float(alpha)
        self.tau_min = float(tau_min)
        self.tau_max = float(tau_max)

    def run_dino(self, x_3ch):
        """
        Minimal robust wrapper to run DINO's patch embedding + transformer
        x_3ch: (B,3,H,W)
        returns: spatial features (B, D, Hp, Wp)
        """
        with torch.no_grad():
            patch_proj = self.dino.patch_embed.proj(x_3ch)  # [B, D, Hp, Wp]
            B, D, Hp, Wp = patch_proj.shape

            tokens = patch_proj.flatten(2).transpose(1, 2)  # [B, L, D]
            cls_tok = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls_tok, tokens), dim=1)  # [B, L+1, D]

            # positional embedding upsample
            pos = self.dino.pos_embed
            orig_N = pos.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))
            pos_spatial = pos[:, 1:, :].transpose(1, 2).reshape(1, D, orig_H, orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp, Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1, D, Hp * Wp).transpose(1, 2)
            pos_all = torch.cat([pos[:, 0:1, :], pos_up], dim=1).to(x_tokens.device)

            x_tokens = x_tokens + pos_all
            x_tokens = self.dino.pos_drop(x_tokens)

            xt = x_tokens
            for blk in self.dino.blocks:
                xt = blk(xt)
            xt = self.dino.norm(xt)

        spatial_tokens = xt[:, 1:, :]
        spatial = spatial_tokens.transpose(1, 2).reshape(B, D, Hp, Wp)
        return spatial

    def forward(self, x, PhiTPhi, PhiTb):
        """
        x: (B, N)
        PhiTPhi: (B,N,N) or (N,N)
        PhiTb: (B,N) or (N,)
        returns: [x_pred, symloss]
        """
        B = x.shape[0]
        N = x.shape[1]

        # ISTA gradient step (vectorized)
        x_vec = x.view(B, N, 1)
        grad = torch.matmul(PhiTPhi, x_vec)
        x_vec = x_vec - self.lambda_step * grad + self.lambda_step * PhiTb.unsqueeze(2)
        x = x_vec.view(B, -1)

        # reshape
        H = 11 * self.c
        x_1ch = x.view(B, 1, H, H)
        x_3ch = x_1ch.repeat(1, 3, 1, 1)

        # forward conv (local)
        h = F.conv2d(x_1ch, self.conv1_forward, padding=1)
        h = F.relu(h)
        x_forward = F.conv2d(h, self.conv2_forward, padding=1)  # [B,64,H,W]

        # local threshold (LSK)
        theta_local = self.theta_local(x_forward)  # [B,1,H,W], typically in (0,1) scaled by module

        # DINO spatial features (upsample to x_forward size)
        spatial = self.run_dino(x_3ch)
        spatial_up = F.interpolate(spatial, size=x_forward.shape[2:], mode='bilinear', align_corners=False)

        # gamma: bounded in (-1,1)
        gamma = self.gamma_mod(spatial_up)  # (B,1,H,W)

        # Residual fusion (safe): theta_final = clamp(theta_local + alpha * gamma, tau_min, tau_max)
        theta_final = theta_local + (self.alpha * gamma)
        theta_final = torch.clamp(theta_final, min=self.tau_min, max=self.tau_max)

        # soft-threshold
        x_thresh = torch.mul(torch.sign(x_forward), F.relu(torch.abs(x_forward) - theta_final))

        # backward conv
        h2 = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        h2 = F.relu(h2)
        x_backward = F.conv2d(h2, self.conv2_backward, padding=1)
        x_pred = x_backward.view(B, -1)

        # symmetry loss
        h_est = F.conv2d(x_forward, self.conv1_backward, padding=1)
        h_est = F.relu(h_est)
        x_est = F.conv2d(h_est, self.conv2_backward, padding=1)
        symloss = x_est - x_1ch

        return [x_pred, symloss]
