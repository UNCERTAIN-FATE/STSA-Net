"""
RSSB_DinoThreshold_DIST_BasicBlock: 方案三RSSB + DINO阈值调制

结合两个已验证有效的方案：
- 方案三RSSB（mAP 0.4674）：全局建模能力
- DinoThresholdBlock（mAP 0.4660）：DINO语义调制动态阈值

创新点：
1. RSSB全局建模 - 7×7大核卷积 + 通道注意力，替代动态卷积分支
2. DINO语义调制动态阈值 - θ = clamp(θ_cnn × (1 + α×γ), τ_min, τ_max)

论文表述：
English: We propose RSSB-DINO-DISTANet with two key innovations:
(1) Residual State Space Block (RSSB) replaces the dynamic convolution branch,
providing global context modeling through large-kernel depthwise convolutions
and channel attention mechanisms;
(2) DINO-guided Dynamic Thresholding leverages pretrained DINOv2 features to
generate semantic-aware modulation maps, enabling adaptive per-pixel soft
thresholds that preserve target signatures while suppressing background clutter.

中文：本文提出RSSB-DINO-DISTANet，包含两个核心创新：
(1) 残差状态空间块(RSSB)替代动态卷积分支，通过大核深度卷积和通道注意力实现全局上下文建模；
(2) DINO引导的动态阈值，利用预训练DINOv2特征生成语义感知的调制图，实现自适应逐像素软阈值，
在抑制背景杂波的同时保留目标特征。

投稿目标：CVPR / ICCV / TIP
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
import math

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# ==================== 创新点1: RSSB模块（来自方案三）====================

class SimpleRSSB(nn.Module):
    """
    简化版残差状态空间块
    来自方案三，已验证mAP 0.4674
    """
    def __init__(self, dim):
        super().__init__()
        
        self.conv1 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.conv2 = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        self.global_conv = nn.Conv2d(dim, dim, 7, 1, 3, groups=dim)
        
        self.channel_mix = nn.Sequential(
            nn.Conv2d(dim, dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(dim * 2, dim, 1)
        )
        
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim // 4, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 4, dim, 1),
            nn.Sigmoid()
        )
        
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        identity = x
        x = self.conv1(x)
        x = F.gelu(x)
        x = x + self.global_conv(x)
        x = self.channel_mix(x)
        x = self.conv2(x)
        x = x * self.ca(x)
        return identity + self.gamma * x


# ==================== 创新点2: DINO阈值调制（来自DinoThresholdBlock）====================

class DinoThresholdModule(nn.Module):
    """
    DINO语义调制动态阈值模块
    来自DinoThresholdBlock，已验证mAP 0.4660
    
    θ_final = clamp(θ_cnn × (1 + α × γ), τ_min, τ_max)
    """
    def __init__(self, in_channels=64, 
                 dino_ckpt="/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth",
                 alpha=0.1, tau_min=1e-4, tau_max=0.06,
                 use_pretrained_dino=True):
        super().__init__()
        
        self.alpha = alpha
        self.tau_min = tau_min
        self.tau_max = tau_max
        self.use_pretrained_dino = use_pretrained_dino
        
        # CNN-based base threshold decoder (local, stable)
        self.th_cnn_decoder = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=1),
            nn.Sigmoid()
        )
        
        if use_pretrained_dino:
            try:
                import timm
                # DINOv2 backbone (frozen)
                self.dino = timm.create_model(
                    'vit_base_patch14_dinov2.lvd142m', 
                    pretrained=False, 
                    num_classes=0, 
                    global_pool=''
                )
                state = torch.load(dino_ckpt, map_location='cpu')
                self.dino.load_state_dict(state, strict=False)
                self.dino.eval()
                for p in self.dino.parameters():
                    p.requires_grad = False
                
                self.dino_dim = 768
                self.dino_available = True
            except Exception as e:
                print(f"Warning: Failed to load DINO: {e}")
                print("Falling back to lightweight feature extractor")
                self.dino_available = False
        else:
            self.dino_available = False
        
        # Gamma projection head
        if self.dino_available:
            self.gamma_proj = nn.Sequential(
                nn.Conv2d(768, 256, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(256, 64, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, 1, 1),
            )
        else:
            # Lightweight fallback
            self.gamma_proj = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, 1, 1),
                nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d(4),
                nn.Conv2d(32, 32, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 1, 1),
            )
    
    def _dino_spatial(self, x_3ch, target_size):
        """
        Extract DINO spatial features
        """
        B = x_3ch.shape[0]
        _, _, H, W = x_3ch.shape
        patch_size = 14
        
        # Upscale to suitable size for DINO
        min_side = max(patch_size * 4, patch_size * math.ceil(max(H, W) / patch_size))
        up_h = int(math.ceil(H / patch_size) * patch_size)
        up_w = int(math.ceil(W / patch_size) * patch_size)
        up_h = max(up_h, min_side)
        up_w = max(up_w, min_side)
        
        x_up = F.interpolate(x_3ch, size=(up_h, up_w), mode='bilinear', align_corners=False)
        
        with torch.no_grad():
            proj = self.dino.patch_embed.proj(x_up)
            Bp, D, Hp, Wp = proj.shape
            tokens = proj.flatten(2).transpose(1, 2)
            cls_token = self.dino.cls_token.expand(B, -1, -1)
            x_tokens = torch.cat((cls_token, tokens), dim=1)
            
            pos_embed = self.dino.pos_embed
            orig_N = pos_embed.shape[1] - 1
            orig_H = orig_W = int(math.sqrt(orig_N))
            pos_spatial = pos_embed[:, 1:, :].transpose(1, 2).reshape(1, D, orig_H, orig_W)
            pos_up = F.interpolate(pos_spatial, size=(Hp, Wp), mode='bilinear', align_corners=False)
            pos_up = pos_up.reshape(1, D, Hp * Wp).transpose(1, 2)
            pos_cls = pos_embed[:, 0:1, :]
            pos = torch.cat([pos_cls, pos_up], dim=1).to(x_tokens.device)
            
            x_tokens = x_tokens + pos
            x_tokens = self.dino.pos_drop(x_tokens)
            
            for blk in self.dino.blocks:
                x_tokens = blk(x_tokens)
            x_tokens = self.dino.norm(x_tokens)
        
        spatial_tokens = x_tokens[:, 1:, :]
        spatial = spatial_tokens.transpose(1, 2).reshape(B, D, Hp, Wp)
        spatial_up = F.interpolate(spatial, size=target_size, mode='bilinear', align_corners=False)
        
        return spatial_up
    
    def forward(self, x_feat, x_img_1ch):
        """
        x_feat: (B, C, H, W) 特征图（用于CNN阈值）
        x_img_1ch: (B, 1, H, W) 原始输入图像（用于DINO）
        返回: (B, 1, H, W) 动态阈值图
        """
        B, C, H, W = x_feat.shape
        
        # CNN-based base threshold
        theta_cnn = self.th_cnn_decoder(x_feat)  # (B, 1, H, W), in (0, 1)
        theta_cnn = theta_cnn * 0.03  # scale to typical threshold range
        
        # DINO-based gamma modulation
        if self.dino_available:
            x_3ch = x_img_1ch.repeat(1, 3, 1, 1)
            spatial_feat = self._dino_spatial(x_3ch, target_size=(H, W))
            gamma_raw = self.gamma_proj(spatial_feat)
        else:
            gamma_raw = self.gamma_proj(x_feat)
            gamma_raw = F.interpolate(gamma_raw, size=(H, W), mode='bilinear', align_corners=False)
        
        # Normalize gamma
        gamma_mean = gamma_raw.mean(dim=[2, 3], keepdim=True)
        gamma = torch.tanh(gamma_raw - gamma_mean)  # in (-1, 1)
        
        # Final modulated threshold
        theta_mod = 1.0 + self.alpha * gamma
        theta = theta_cnn * theta_mod
        theta = torch.clamp(theta, min=self.tau_min, max=self.tau_max)
        
        return theta


# ==================== 主模块 ====================

class RSSB_DinoThreshold_DIST_BasicBlock(nn.Module):
    """
    RSSB + DINO阈值调制 DIST BasicBlock
    
    结合两个已验证方案：
    - 方案三RSSB（mAP 0.4674）
    - DinoThresholdBlock（mAP 0.4660）
    
    创新点：
    1. RSSB全局建模 - 替代动态卷积分支
    2. DINO语义调制动态阈值 - θ = clamp(θ_cnn × (1 + α×γ), τ_min, τ_max)
    """
    def __init__(self, **kwargs):
        super(RSSB_DinoThreshold_DIST_BasicBlock, self).__init__()
        
        c = kwargs['c']
        lambda_weight = kwargs.get('lambda_weight', 0.7)
        dino_ckpt = kwargs.get('dino_ckpt', '/root/autodl-tmp/grokcso/pretrained/dinov2_vitb14.pth')
        alpha = kwargs.get('alpha', 0.1)
        tau_min = kwargs.get('tau_min', 1e-4)
        tau_max = kwargs.get('tau_max', 0.06)
        use_pretrained_dino = kwargs.get('use_pretrained_dino', True)
        
        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.c = c
        
        # ===== 静态分支（保持原设计）=====
        self.conv1_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 1, 3, 3)))
        self.conv2_forward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        
        # ===== 【创新点1】RSSB分支 =====
        self.rssb_proj = nn.Conv2d(1, 64, 3, 1, 1)
        self.rssb_block = SimpleRSSB(64)
        
        # ===== 【创新点2】DINO阈值调制模块 =====
        self.dino_threshold = DinoThresholdModule(
            in_channels=64,
            dino_ckpt=dino_ckpt,
            alpha=alpha,
            tau_min=tau_min,
            tau_max=tau_max,
            use_pretrained_dino=use_pretrained_dino
        )
        
        # ===== 后向变换 =====
        self.conv1_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(64, 64, 3, 3)))
        self.conv2_backward = nn.Parameter(
            init.xavier_normal_(torch.Tensor(1, 64, 3, 3)))
        
        self.lambda_weight = torch.Tensor([lambda_weight]).to(device)
        
    def forward(self, x, PhiTPhi, PhiTb):
        # ISTA梯度下降步
        x = x - self.lambda_step * torch.mm(x, PhiTPhi)
        x = x + self.lambda_step * PhiTb
        x_input = x.view(-1, 1, 11 * self.c, 11 * self.c)
        
        # ===== 静态分支 =====
        x_s = F.conv2d(x_input, self.conv1_forward, padding=1)
        x_s = F.relu(x_s)
        x_forward = F.conv2d(x_s, self.conv2_forward, padding=1)
        
        # ===== 【创新点1】RSSB分支 =====
        x_rssb = self.rssb_proj(x_input)
        x_rssb = self.rssb_block(x_rssb)
        
        # ===== 双分支融合 =====
        x_combined = self.lambda_weight * x_forward + \
                     (1 - self.lambda_weight) * x_rssb
        
        # ===== 【创新点2】DINO动态阈值 =====
        theta = self.dino_threshold(x_combined, x_input)
        
        # 软阈值
        x_thresh = torch.sign(x_combined) * F.relu(torch.abs(x_combined) - theta)
        
        # ===== 后向变换 =====
        x_b = F.conv2d(x_thresh, self.conv1_backward, padding=1)
        x_b = F.relu(x_b)
        x_backward = F.conv2d(x_b, self.conv2_backward, padding=1)
        
        x_pred = x_backward.view(-1, 11 * self.c * 11 * self.c)
        
        # ===== 对称损失 =====
        x_sym = F.conv2d(x_combined, self.conv1_backward, padding=1)
        x_sym = F.relu(x_sym)
        x_est = F.conv2d(x_sym, self.conv2_backward, padding=1)
        symloss = x_est - x_input
        
        return [x_pred, symloss]


# ==================== 测试 ====================

if __name__ == "__main__":
    print("Testing RSSB_DinoThreshold_DIST_BasicBlock...")
    
    batch_size = 4  # 小batch测试，因为DINO占显存
    c = 3
    
    # 测试时不用预训练DINO（避免加载问题）
    block = RSSB_DinoThreshold_DIST_BasicBlock(
        c=c, 
        lambda_weight=0.7,
        use_pretrained_dino=False  # 测试时用轻量版
    )
    block = block.to(device)
    
    x = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    PhiTPhi = torch.randn(11 * 11 * c * c, 11 * 11 * c * c).to(device)
    PhiTb = torch.randn(batch_size, 11 * 11 * c * c).to(device)
    
    output, symloss = block(x, PhiTPhi, PhiTb)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Symloss shape: {symloss.shape}")
    
    total_params = sum(p.numel() for p in block.parameters() if p.requires_grad)
    print(f"Trainable parameters: {total_params:,}")
    
    print("Test passed!")