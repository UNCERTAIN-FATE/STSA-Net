from .cso_mean_ap import eval_map2

__all__ = [
  "eval_map2",
]
